/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Header 
} from './components/Header';
import { 
  HeroSlider 
} from './components/HeroSlider';
import { 
  CategoryGrid 
} from './components/CategoryGrid';
import { 
  ProductCard 
} from './components/ProductCard';
import { 
  ProductModal 
} from './components/ProductModal';
import { 
  SizeGuideModal 
} from './components/SizeGuideModal';
import { 
  FilterSidebar 
} from './components/FilterSidebar';
import { 
  CartDrawer 
} from './components/CartDrawer';
import { 
  CheckoutModal 
} from './components/CheckoutModal';
import { 
  OrderTrackerModal 
} from './components/OrderTrackerModal';
import { 
  AiStylistModal 
} from './components/AiStylistModal';
import { 
  Footer 
} from './components/Footer';

import { Product, CartItem, FilterState, Order, ProductCategory, SubCategory } from './types';
import { PRODUCTS } from './data/products';
import { Sparkles, Heart, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';

export default function App() {
  const [language, setLanguage] = useState<'en' | 'hi'>('en');
  
  // Cart & Wishlist state
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);

  // Filter State
  const [filterState, setFilterState] = useState<FilterState>({
    searchQuery: '',
    category: 'all',
    subcategories: [],
    priceRange: [0, 6000],
    sizes: [],
    colors: [],
    sortOption: 'featured',
    discountOnly: false,
    inStockOnly: false
  });

  // Modal Open Toggles
  const [cartOpen, setCartOpen] = useState(false);
  const [wishlistOpen, setWishlistOpen] = useState(false);
  const [orderTrackerOpen, setOrderTrackerOpen] = useState(false);
  const [aiStylistOpen, setAiStylistOpen] = useState(false);
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Discount from Cart
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [appliedPromoCode, setAppliedPromoCode] = useState('');

  // Wishlist Handlers
  const handleToggleWishlist = (product: Product) => {
    setWishlist(prev => {
      const exists = prev.some(p => p.id === product.id);
      if (exists) return prev.filter(p => p.id !== product.id);
      return [...prev, product];
    });
  };

  // Cart Handlers
  const handleAddToCart = (product: Product, size: string, color: string, qty = 1) => {
    const itemId = `${product.id}-${size}-${color}`;
    setCartItems(prev => {
      const existing = prev.find(item => item.id === itemId);
      if (existing) {
        return prev.map(item =>
          item.id === itemId ? { ...item, quantity: item.quantity + qty } : item
        );
      }
      return [...prev, { id: itemId, product, selectedSize: size, selectedColor: color, quantity: qty }];
    });
  };

  const handleUpdateCartQty = (cartItemId: string, delta: number) => {
    setCartItems(prev =>
      prev
        .map(item => {
          if (item.id === cartItemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (cartItemId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== cartItemId));
  };

  const handleProceedToCheckout = (discountAmount: number, code: string) => {
    setAppliedDiscount(discountAmount);
    setAppliedPromoCode(code);
    setCartOpen(false);
    setCheckoutOpen(true);
  };

  const handleBuyNow = (product: Product, size: string, color: string) => {
    handleAddToCart(product, size, color, 1);
    setQuickViewProduct(null);
    setCheckoutOpen(true);
  };

  const handleOrderSuccess = (newOrder: Order) => {
    setRecentOrders(prev => [newOrder, ...prev]);
    setCartItems([]);
  };

  const handleSelectSubcategory = (sub: SubCategory, parentCat: ProductCategory) => {
    setFilterState(prev => ({
      ...prev,
      category: parentCat,
      subcategories: [sub]
    }));
  };

  // Filtered Products Memo
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(p => {
      // Main Category Filter
      if (filterState.category !== 'all' && p.category !== filterState.category) return false;

      // Subcategories
      if (filterState.subcategories.length > 0 && !filterState.subcategories.includes(p.subcategory)) return false;

      // Search
      if (filterState.searchQuery) {
        const q = filterState.searchQuery.toLowerCase();
        const matchTitle = p.title.toLowerCase().includes(q) || (p.titleHindi && p.titleHindi.includes(q));
        const matchTags = p.tags.some(t => t.toLowerCase().includes(q));
        if (!matchTitle && !matchTags) return false;
      }

      // Price Range
      if (p.price > filterState.priceRange[1]) return false;

      // Sizes
      if (filterState.sizes.length > 0) {
        const hasSize = p.sizes.some(s => filterState.sizes.includes(s));
        if (!hasSize) return false;
      }

      // Discount Only
      if (filterState.discountOnly && p.discountPercentage < 50) return false;

      return true;
    }).sort((a, b) => {
      if (filterState.sortOption === 'price-low-high') return a.price - b.price;
      if (filterState.sortOption === 'price-high-low') return b.price - a.price;
      if (filterState.sortOption === 'rating') return b.rating - a.rating;
      if (filterState.sortOption === 'discount') return b.discountPercentage - a.discountPercentage;
      return 0; // featured default
    });
  }, [filterState]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col justify-between selection:bg-amber-200 selection:text-amber-900">
      
      {/* Top Header Navbar */}
      <Header
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
        wishlistCount={wishlist.length}
        activeCategory={filterState.category}
        setActiveCategory={(cat) => setFilterState(prev => ({ ...prev, category: cat, subcategories: [] }))}
        searchQuery={filterState.searchQuery}
        setSearchQuery={(q) => setFilterState(prev => ({ ...prev, searchQuery: q }))}
        openCart={() => setCartOpen(true)}
        openWishlist={() => setWishlistOpen(true)}
        openOrderTracker={() => setOrderTrackerOpen(true)}
        openAiStylist={() => setAiStylistOpen(true)}
        language={language}
        setLanguage={setLanguage}
      />

      {/* Main Content Body */}
      <main className="flex-1 pb-12">
        
        {/* Hero Banner Carousel */}
        <HeroSlider
          onSelectCategory={(cat) => setFilterState(prev => ({ ...prev, category: cat, subcategories: [] }))}
          onOpenAiStylist={() => setAiStylistOpen(true)}
          language={language}
        />

        {/* Category Shortcuts Grid */}
        <CategoryGrid
          onSelectSubcategory={handleSelectSubcategory}
          language={language}
        />

        {/* Catalog Section with Sidebar Filters */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 my-8">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-200">
            <div>
              <span className="text-amber-800 text-xs font-bold uppercase tracking-wider bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-200">
                JANU TRENDS CATALOG
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                {filterState.category === 'all' && (language === 'hi' ? 'सभी कपड़े (All Clothing)' : 'All Fashion Collections')}
                {filterState.category === 'menswear' && (language === 'hi' ? 'मेन्सवेयर कलेक्शन' : 'Menswear Fashion')}
                {filterState.category === 'kidswear' && (language === 'hi' ? 'किड्सवेयर कलेक्शन' : 'Kids Wear Fashion')}
              </h2>
            </div>

            <button
              onClick={() => setAiStylistOpen(true)}
              className="bg-amber-100 hover:bg-amber-200 text-amber-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 border border-amber-300 transition-colors cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-700" />
              <span>{language === 'hi' ? 'AI आउटफिट सलाह' : 'Ask AI Stylist'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
            
            {/* Left Filter Sidebar */}
            <div className="lg:col-span-1 sticky top-24">
              <FilterSidebar
                filterState={filterState}
                setFilterState={setFilterState}
                totalResults={filteredProducts.length}
                language={language}
              />
            </div>

            {/* Right Product Grid */}
            <div className="lg:col-span-3">
              {filteredProducts.length === 0 ? (
                <div className="bg-white rounded-3xl p-10 border border-slate-200 text-center space-y-3 shadow-xs">
                  <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center mx-auto">
                    <Sparkles className="w-8 h-8" />
                  </div>
                  <h3 className="font-extrabold text-lg text-slate-900">
                    {language === 'hi' ? 'कोई उत्पाद नहीं मिला' : 'No Clothing Items Match Your Filters'}
                  </h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Try clearing your price or size filters to discover our entire Menswear & Kids Wear range.
                  </p>
                  <button
                    onClick={() => setFilterState({
                      searchQuery: '',
                      category: 'all',
                      subcategories: [],
                      priceRange: [0, 6000],
                      sizes: [],
                      colors: [],
                      sortOption: 'featured',
                      discountOnly: false,
                      inStockOnly: false
                    })}
                    className="bg-amber-950 text-amber-200 font-bold px-5 py-2.5 rounded-xl text-xs hover:bg-amber-900 transition-colors cursor-pointer"
                  >
                    Clear All Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                  {filteredProducts.map((prod) => (
                    <ProductCard
                      key={prod.id}
                      product={prod}
                      isWishlisted={wishlist.some(p => p.id === prod.id)}
                      onToggleWishlist={handleToggleWishlist}
                      onQuickView={(p) => setQuickViewProduct(p)}
                      onAddToCart={handleAddToCart}
                      language={language}
                    />
                  ))}
                </div>
              )}
            </div>

          </div>
        </section>

      </main>

      {/* Footer */}
      <Footer
        onSelectCategory={(cat) => setFilterState(prev => ({ ...prev, category: cat, subcategories: [] }))}
        openOrderTracker={() => setOrderTrackerOpen(true)}
        openAiStylist={() => setAiStylistOpen(true)}
        language={language}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQty}
        onRemoveItem={handleRemoveCartItem}
        onProceedToCheckout={handleProceedToCheckout}
        language={language}
      />

      {/* Wishlist Drawer */}
      {wishlistOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex justify-end animate-fadeIn">
          <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between overflow-hidden relative p-5">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-rose-500 fill-current" />
                <h3 className="font-extrabold text-base text-slate-900 uppercase">
                  Wishlist ({wishlist.length})
                </h3>
              </div>
              <button onClick={() => setWishlistOpen(false)} className="p-1.5 text-slate-400 hover:text-slate-700">
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-3">
              {wishlist.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs">
                  Your Wishlist is empty. Tap the heart on products to save them!
                </div>
              ) : (
                wishlist.map((p) => (
                  <div key={p.id} className="bg-slate-50 p-3 rounded-2xl border border-slate-200 flex gap-3 items-center justify-between">
                    <img src={p.images[0]} alt="" className="w-14 h-16 object-cover object-top rounded-xl border" />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-xs text-slate-900 truncate">{p.title}</h4>
                      <span className="font-black text-xs text-amber-900">₹{p.price.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          handleAddToCart(p, p.sizes[0] || 'M', p.colors[0]?.name || 'Standard', 1);
                          setWishlistOpen(false);
                          setCartOpen(true);
                        }}
                        className="bg-amber-950 text-amber-200 text-xs font-bold p-2 rounded-xl"
                      >
                        <ShoppingBag className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleToggleWishlist(p)} className="p-2 text-slate-400 hover:text-rose-600">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Product Detail Modal */}
      <ProductModal
        product={quickViewProduct}
        isOpen={!!quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        isWishlisted={quickViewProduct ? wishlist.some(p => p.id === quickViewProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
        onOpenSizeGuide={() => setSizeGuideOpen(true)}
        language={language}
      />

      {/* Size Guide Modal */}
      <SizeGuideModal
        category={quickViewProduct?.category || filterState.category === 'kidswear' ? 'kidswear' : 'menswear'}
        isOpen={sizeGuideOpen}
        onClose={() => setSizeGuideOpen(false)}
        language={language}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        cartItems={cartItems}
        discountAmount={appliedDiscount}
        appliedCode={appliedPromoCode}
        onOrderSuccess={handleOrderSuccess}
        language={language}
      />

      {/* Live Order Tracker Modal */}
      <OrderTrackerModal
        isOpen={orderTrackerOpen}
        onClose={() => setOrderTrackerOpen(false)}
        recentOrders={recentOrders}
        language={language}
      />

      {/* AI Stylist Assistant Modal */}
      <AiStylistModal
        isOpen={aiStylistOpen}
        onClose={() => setAiStylistOpen(false)}
        onSelectProduct={(p) => setQuickViewProduct(p)}
        language={language}
      />

    </div>
  );
}
