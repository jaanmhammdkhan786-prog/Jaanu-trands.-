import { Product } from '../types';

export const PRODUCTS: Product[] = [
  // --- MENSWEAR ---
  {
    id: 'm1',
    title: 'Royal Ethnic Silk Blend Mens Kurta Set',
    titleHindi: 'रॉयल सिल्क ब्लेंड मेन्स कुर्ता सेट',
    category: 'menswear',
    subcategory: 'mens_ethnic',
    price: 1499,
    originalPrice: 2999,
    discountPercentage: 50,
    rating: 4.8,
    reviewsCount: 142,
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1597983073493-88cd35cf03b0?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Maroon', hex: '#800000' },
      { name: 'Navy Blue', hex: '#000080' },
      { name: 'Royal Gold', hex: '#DAA520' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    tags: ['Festive', 'Ethnic', 'Wedding', 'Bestseller'],
    description: 'Elevate your festive wardrobe with Janu Trends Royal Silk Blend Kurta Pajama set. Features intricate mandarin collar embroidery and lightweight breathable fabric.',
    descriptionHindi: 'जानू ट्रेंड्स के इस रॉयल सिल्क कुर्ता सेट के साथ अपने फेस्टिव लुक को बेहतर बनाएं।',
    fabric: 'Premium Silk Blend Cotton',
    care: 'Dry Clean Only or Gentle Hand Wash',
    isBestseller: true,
    isNew: false,
    inStock: true
  },
  {
    id: 'm2',
    title: 'Urban Slim-Fit Casual Cotton Shirt',
    titleHindi: 'अर्बन स्लिम-फिट कॉटन शर्ट',
    category: 'menswear',
    subcategory: 'mens_shirts',
    price: 799,
    originalPrice: 1599,
    discountPercentage: 50,
    rating: 4.6,
    reviewsCount: 98,
    images: [
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Olive Green', hex: '#556B2F' },
      { name: 'White', hex: '#FFFFFF' },
      { name: 'Charcoal', hex: '#36454F' }
    ],
    sizes: ['M', 'L', 'XL', 'XXL'],
    tags: ['Casual', 'Office Wear', 'Trendy'],
    description: 'Tailored to perfection, this 100% pure cotton casual shirt offers a sharp modern look with all-day comfort for work or casual hangouts.',
    descriptionHindi: '100% शुद्ध सूती शर्ट जो आपको ऑफिस और कैजुअल मौकों पर शानदार लुक देती है।',
    fabric: '100% Combed Cotton',
    care: 'Machine Wash Warm, Do Not Bleach',
    isBestseller: true,
    inStock: true
  },
  {
    id: 'm3',
    title: 'Streetwear Graphic Printed Oversized Tee',
    titleHindi: 'स्ट्रीटवेयर प्रिंटेड ओवरसाइज़्ड टी-शर्ट',
    category: 'menswear',
    subcategory: 'mens_tshirts',
    price: 499,
    originalPrice: 999,
    discountPercentage: 50,
    rating: 4.7,
    reviewsCount: 215,
    images: [
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Black', hex: '#000000' },
      { name: 'Beige', hex: '#F5F5DC' },
      { name: 'Sage Green', hex: '#9DC183' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    tags: ['Streetwear', 'Oversized', 'College Trend', 'New Arrival'],
    description: 'High-density puff graphic oversized heavy cotton T-shirt. Drop shoulder fit designed for youth street style.',
    descriptionHindi: 'ड्रॉप शोल्डर ओवरसाइज़्ड टी-शर्ट युवाओं के लेटेस्ट स्ट्रीट स्टाइल ट्रेंड के लिए।',
    fabric: '240 GSM Heavyweight Cotton',
    care: 'Wash inside out in cold water',
    isNew: true,
    inStock: true
  },
  {
    id: 'm4',
    title: 'Premium Tailored Blazer Suit Jacket',
    titleHindi: 'प्रीमियम टेलर ब्लेज़र सूट जैकेट',
    category: 'menswear',
    subcategory: 'mens_jackets',
    price: 2999,
    originalPrice: 5999,
    discountPercentage: 50,
    rating: 4.9,
    reviewsCount: 76,
    images: [
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Midnight Navy', hex: '#191970' },
      { name: 'Classic Black', hex: '#1A1A1A' }
    ],
    sizes: ['38 (M)', '40 (L)', '42 (XL)', '44 (XXL)'],
    tags: ['Party Wear', 'Formal', 'Wedding Blazer'],
    description: 'Structure and finesse combined. Single-breasted two-button blazer crafted with fine wool blend for grand occasions.',
    descriptionHindi: 'पार्टी और शादी-समारोह के लिए क्लासिक दो-बटन लग्जरी ब्लेज़र।',
    fabric: 'Fine Wool Poly Blend',
    care: 'Dry Clean Only',
    isBestseller: true,
    inStock: true
  },
  {
    id: 'm5',
    title: 'Janu Trends Rugged Stretch Denim Jeans',
    titleHindi: 'जानू ट्रेंड्स स्ट्रैच डेनिम जीन्स',
    category: 'menswear',
    subcategory: 'mens_bottoms',
    price: 1199,
    originalPrice: 2399,
    discountPercentage: 50,
    rating: 4.5,
    reviewsCount: 188,
    images: [
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1542272604-780c36856842?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Dark Indigo', hex: '#1F2937' },
      { name: 'Light Wash', hex: '#60A5FA' }
    ],
    sizes: ['30', '32', '34', '36', '38'],
    tags: ['Jeans', 'Stretchable', 'Daily Wear'],
    description: 'Slim tapered stretch denim jeans with comfortable elastane flexibility and durable double stitching.',
    descriptionHindi: 'आरामदायक और टिकाऊ स्लिम-फिट फ्लेक्सिबल डेनिम जीन्स।',
    fabric: '98% Cotton Denim, 2% Elastane',
    care: 'Machine Wash Cold inside out',
    inStock: true
  },
  {
    id: 'm6',
    title: 'Designer Nehru Jacket Velvet Blend',
    titleHindi: 'डिजाइनर नेहरू जैकेट वेलवेट ब्लेंड',
    category: 'menswear',
    subcategory: 'mens_jackets',
    price: 1299,
    originalPrice: 2599,
    discountPercentage: 50,
    rating: 4.8,
    reviewsCount: 64,
    images: [
      'https://images.unsplash.com/photo-1597983073493-88cd35cf03b0?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Royal Emerald', hex: '#046307' },
      { name: 'Wine Red', hex: '#722F37' }
    ],
    sizes: ['38', '40', '42', '44'],
    tags: ['Festive', 'Nehru Jacket', 'Traditional'],
    description: 'Layer over any simple kurta or formal shirt to add instantly festive elegance. Premium brass button detailing.',
    descriptionHindi: 'कुर्ते या शर्ट के ऊपर पहनकर तुरंत रीगल लुक पाएं।',
    fabric: 'Velvet Silk Blend',
    care: 'Dry Clean Only',
    isNew: true,
    inStock: true
  },

  // --- KIDS WEAR ---
  {
    id: 'k1',
    title: 'Boys Festive Kurta Dhoti Set with Jacket',
    titleHindi: 'बॉयज़ फेस्टिव कुर्ता धोती और जैकेट सेट',
    category: 'kidswear',
    subcategory: 'kids_ethnic',
    price: 999,
    originalPrice: 1999,
    discountPercentage: 50,
    rating: 4.9,
    reviewsCount: 167,
    images: [
      'https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1503944583220-79d8926ad5e2?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Yellow Gold', hex: '#EAB308' },
      { name: 'Sky Blue', hex: '#38BDF8' }
    ],
    sizes: ['2Y-3Y', '4Y-5Y', '6Y-7Y', '8Y-9Y', '10Y-12Y'],
    tags: ['Kids Festive', 'Boys Ethnic', 'Diwali Special', 'Kids Bestseller'],
    description: 'Super soft skin-friendly cotton silk ethnic suit for boys. Includes Kurta, pre-stitched ready dhoti pants, and embroidered Modi jacket.',
    descriptionHindi: 'बच्चों की नाजुक त्वचा के लिए बहुत मुलायम कॉटन सिल्क कुर्ता धोती सेट।',
    fabric: 'Soft Cotton Silk Blend',
    care: 'Hand Wash Gently in cold water',
    isBestseller: true,
    isNew: false,
    inStock: true
  },
  {
    id: 'k2',
    title: 'Boys Smart Tuxedo Party Suit 3-Piece',
    titleHindi: 'बॉयज़ 3-पीस पार्टी टक्सीडो सूट',
    category: 'kidswear',
    subcategory: 'kids_sets',
    price: 1399,
    originalPrice: 2799,
    discountPercentage: 50,
    rating: 4.8,
    reviewsCount: 89,
    images: [
      'https://images.unsplash.com/photo-1503944583220-79d8926ad5e2?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Classic Black', hex: '#18181B' },
      { name: 'Navy Blue', hex: '#1E3A8A' }
    ],
    sizes: ['3Y-4Y', '5Y-6Y', '7Y-8Y', '9Y-10Y', '11Y-12Y'],
    tags: ['Birthday Wear', 'Party Suit', 'Dapper Boy'],
    description: '3-Piece formal gentleman set for boys including waistcoat, formal trousers, shirt, and bowtie. Perfect for birthday parties and family functions.',
    descriptionHindi: 'बर्थडे और पार्टीज़ के लिए बच्चों का स्मार्ट 3-पीस सूट सेट।',
    fabric: 'Polyester Rayon Suiting Blend',
    care: 'Dry Clean Recommended',
    isBestseller: true,
    inStock: true
  },
  {
    id: 'k3',
    title: 'Girls Fairy Tale Flared Party Gown',
    titleHindi: 'गर्ल्स फेयरी टेल पार्टी फ्रॉक',
    category: 'kidswear',
    subcategory: 'kids_girls',
    price: 1099,
    originalPrice: 2199,
    discountPercentage: 50,
    rating: 4.7,
    reviewsCount: 112,
    images: [
      'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Blush Pink', hex: '#F472B6' },
      { name: 'Peach', hex: '#FDBA74' },
      { name: 'Lavender', hex: '#C084FC' }
    ],
    sizes: ['2Y-3Y', '4Y-5Y', '6Y-7Y', '8Y-9Y', '10Y-12Y'],
    tags: ['Girls Party Dress', 'Princess Gown', 'Cute Kids'],
    description: 'Magical multi-layered net flare dress with soft inner cotton lining for itch-free comfort. Sequin bow applique detailing.',
    descriptionHindi: 'सॉफ्ट कॉटन इनर लाइनिंग के साथ बच्चियों के लिए सुंदर पार्टी फ्रॉक।',
    fabric: 'Soft Net with 100% Cotton Lining',
    care: 'Gentle Hand Wash',
    isNew: true,
    inStock: true
  },
  {
    id: 'k4',
    title: 'Kids Denim Jacket & Printed Joggers Set',
    titleHindi: 'किड्स डेनिम जैकेट और जॉगर्स सेट',
    category: 'kidswear',
    subcategory: 'kids_sets',
    price: 899,
    originalPrice: 1799,
    discountPercentage: 50,
    rating: 4.6,
    reviewsCount: 145,
    images: [
      'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Blue Denim', hex: '#2563EB' },
      { name: 'Olive Gray', hex: '#475569' }
    ],
    sizes: ['2Y-3Y', '4Y-5Y', '6Y-7Y', '8Y-9Y'],
    tags: ['Casual Wear', 'Cool Kids', 'Co-ord Set'],
    description: 'Trendy casual 2-piece combo with stretchy denim jacket and soft cotton printed joggers. Durable and playground ready.',
    descriptionHindi: 'बच्चों के लिए कूल और आरामदायक डेनिम जैकेट और जॉगर्स कम्बो।',
    fabric: 'Stretch Denim & Combed Cotton',
    care: 'Machine Washable',
    inStock: true
  },
  {
    id: 'k5',
    title: 'Girls Designer Lehenga Choli Set',
    titleHindi: 'गर्ल्स डिजाइनर लहंगा चोली सेट',
    category: 'kidswear',
    subcategory: 'kids_ethnic',
    price: 1299,
    originalPrice: 2599,
    discountPercentage: 50,
    rating: 4.9,
    reviewsCount: 94,
    images: [
      'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Rani Pink', hex: '#DB2777' },
      { name: 'Bright Yellow', hex: '#FACC15' }
    ],
    sizes: ['3Y-4Y', '5Y-6Y', '7Y-8Y', '9Y-10Y', '11Y-12Y'],
    tags: ['Festive', 'Traditional Girls', 'Wedding Kids'],
    description: 'Charming festive brocade jacquard lehenga with elastic waistband and matching blouse with dupatta.',
    descriptionHindi: 'त्योहारों के लिए सुंदर ब्रोकेड लहंगा चोली सेट।',
    fabric: 'Jacquard Silk with Cotton lining',
    care: 'Dry Clean Only',
    isNew: true,
    inStock: true
  },
  {
    id: 'k6',
    title: 'Kids Fleece Hooded Sweatshirt Pullover',
    titleHindi: 'किड्स फ्लीस हुडेड स्वेटशर्ट',
    category: 'kidswear',
    subcategory: 'kids_jackets',
    price: 599,
    originalPrice: 1199,
    discountPercentage: 50,
    rating: 4.8,
    reviewsCount: 210,
    images: [
      'https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?auto=format&fit=crop&q=80&w=800'
    ],
    colors: [
      { name: 'Mustard Yellow', hex: '#CA8A04' },
      { name: 'Crimson Red', hex: '#DC2626' },
      { name: 'Navy', hex: '#1D4ED8' }
    ],
    sizes: ['2Y-3Y', '4Y-5Y', '6Y-7Y', '8Y-9Y', '10Y-12Y'],
    tags: ['Winter Wear', 'Warm Hoodies', 'Kids Essentials'],
    description: 'Super cozy brushed fleece hoodie to keep your little ones warm and comfortable all day long.',
    descriptionHindi: 'बच्चों के लिए बहुत ही गरम और आरामदायक फ्लीस हुडी।',
    fabric: 'Soft Fleece Brushed Cotton',
    care: 'Machine wash warm',
    inStock: true
  }
];

export const PROMO_CODES: Record<string, { discountPercent: number; maxDiscount: number; minOrder: number; description: string }> = {
  JANU10: {
    discountPercent: 10,
    maxDiscount: 200,
    minOrder: 499,
    description: '10% OFF on all items above ₹499'
  },
  FESTIVE20: {
    discountPercent: 20,
    maxDiscount: 500,
    minOrder: 999,
    description: '20% OFF Festive Discount on orders above ₹999'
  },
  KIDS15: {
    discountPercent: 15,
    maxDiscount: 300,
    minOrder: 699,
    description: '15% OFF Special Kids Wear discount'
  }
};
