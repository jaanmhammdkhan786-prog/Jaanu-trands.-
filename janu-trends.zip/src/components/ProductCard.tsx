import React from 'react';
import { Heart, Star, Eye, ShoppingBag, Check } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (p: Product) => void;
  onQuickView: (p: Product) => void;
  onAddToCart: (p: Product, size: string, color: string) => void;
  language: 'en' | 'hi';
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onQuickView,
  onAddToCart,
  language
}) => {
  const [selectedSize, setSelectedSize] = React.useState<string>(product.sizes[0] || 'M');
  const [selectedColor, setSelectedColor] = React.useState<string>(product.colors[0]?.name || 'Standard');
  const [addedAnimation, setAddedAnimation] = React.useState(false);

  const handleAddCartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, selectedSize, selectedColor);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1500);
  };

  return (
    <div 
      onClick={() => onQuickView(product)}
      className="group relative bg-white border border-slate-900 overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer"
    >
      {/* Top Image Container */}
      <div className="relative aspect-3/4 w-full bg-slate-100 overflow-hidden border-b border-slate-900">
        <img
          src={product.images[0]}
          alt={product.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-top filter grayscale-10 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-500"
        />

        {/* Geometric Sharp Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1 items-start z-10">
          {product.discountPercentage > 0 && (
            <span className="bg-slate-900 text-white font-bold text-[9px] px-2 py-0.5 border border-slate-900 uppercase tracking-widest">
              -{product.discountPercentage}%
            </span>
          )}
          {product.isBestseller && (
            <span className="bg-white text-slate-900 border border-slate-900 font-bold text-[9px] px-2 py-0.5 uppercase tracking-widest">
              BESTSELLER
            </span>
          )}
          {product.isNew && (
            <span className="bg-amber-600 text-white border border-amber-600 font-bold text-[9px] px-2 py-0.5 uppercase tracking-widest">
              NEW
            </span>
          )}
        </div>

        {/* Wishlist & Quick View Floating Buttons */}
        <div className="absolute top-2 right-2 flex flex-col gap-1.5 z-10">
          <button
            id={`wishlist-btn-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(product);
            }}
            className={`p-1.5 border border-slate-900 shadow-sm transition-all cursor-pointer ${
              isWishlisted
                ? 'bg-rose-600 text-white border-rose-600'
                : 'bg-white text-slate-900 hover:bg-slate-900 hover:text-white'
            }`}
            title="Add to Wishlist"
          >
            <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-current' : ''}`} />
          </button>

          <button
            id={`quickview-btn-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onQuickView(product);
            }}
            className="p-1.5 bg-white text-slate-900 border border-slate-900 hover:bg-slate-900 hover:text-white shadow-sm transition-all cursor-pointer"
            title="Quick View"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Quick Size Selection Pill bar on Hover */}
        <div className="absolute bottom-2 left-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10 bg-white border border-slate-900 p-1 flex items-center justify-center gap-1">
          {product.sizes.map((sz) => (
            <button
              key={sz}
              onClick={(e) => {
                e.stopPropagation();
                setSelectedSize(sz);
              }}
              className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 border cursor-pointer ${
                selectedSize === sz
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-900 border-slate-200 hover:border-slate-900'
              }`}
            >
              {sz}
            </button>
          ))}
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Category & Ratings */}
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-bold uppercase tracking-widest text-[9px] text-slate-900 border border-slate-900 px-1.5 py-0.5">
              {product.category === 'menswear' ? (language === 'hi' ? 'मेन्सवेयर' : 'Menswear') : (language === 'hi' ? 'किड्सवेयर' : 'Kidswear')}
            </span>

            <div className="flex items-center gap-1 text-slate-900 font-bold text-xs">
              <Star className="w-3.5 h-3.5 fill-slate-900 text-slate-900" />
              <span>{product.rating}</span>
              <span className="text-slate-400 text-[10px]">({product.reviewsCount})</span>
            </div>
          </div>

          {/* Title in Serif */}
          <h3 className="font-serif font-bold text-slate-900 text-sm uppercase tracking-tight line-clamp-2 hover:line-through transition-all mt-1">
            {language === 'hi' && product.titleHindi ? product.titleHindi : product.title}
          </h3>
        </div>

        {/* Color Swatches */}
        {product.colors && product.colors.length > 0 && (
          <div className="flex items-center gap-1.5 pt-1">
            {product.colors.map((c) => (
              <button
                key={c.name}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedColor(c.name);
                }}
                className={`w-3.5 h-3.5 border border-slate-900 transition-all cursor-pointer ${
                  selectedColor === c.name ? 'scale-125 ring-1 ring-slate-900' : 'opacity-70 hover:opacity-100'
                }`}
                style={{ backgroundColor: c.hex }}
                title={c.name}
              />
            ))}
            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold ml-1 truncate">
              {selectedColor}
            </span>
          </div>
        )}

        {/* Price & Add to Cart Action */}
        <div className="pt-2 border-t border-slate-900 flex items-center justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-base sm:text-lg font-serif font-extrabold text-slate-900">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
              {product.originalPrice > product.price && (
                <span className="text-xs text-slate-400 line-through">
                  ₹{product.originalPrice.toLocaleString('en-IN')}
                </span>
              )}
            </div>
          </div>

          <button
            id={`add-cart-btn-${product.id}`}
            onClick={handleAddCartClick}
            className={`px-3 py-2 border border-slate-900 font-bold text-[10px] uppercase tracking-widest flex items-center gap-1.5 transition-all cursor-pointer ${
              addedAnimation
                ? 'bg-emerald-700 text-white border-emerald-700'
                : 'bg-slate-900 hover:bg-slate-800 text-white'
            }`}
          >
            {addedAnimation ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'जोड़ा गया' : 'Added'}</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5 text-white" />
                <span>{language === 'hi' ? 'कार्ट में जोड़ें' : 'Add'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
