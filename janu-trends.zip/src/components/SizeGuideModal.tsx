import React from 'react';
import { X, Ruler, CheckCircle2 } from 'lucide-react';
import { ProductCategory } from '../types';

interface SizeGuideModalProps {
  category: ProductCategory;
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'hi';
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({
  category,
  isOpen,
  onClose,
  language
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-white max-w-xl w-full max-h-[90vh] overflow-y-auto border border-slate-900 p-6 relative shadow-lg">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-slate-900 flex items-center justify-center text-white border border-slate-900">
              <Ruler className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-serif font-bold text-slate-900 uppercase tracking-wider">
                {language === 'hi' ? 'साइज़ गाइड चार्ट' : 'OFFICIAL SIZE GUIDE'}
              </h3>
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500">
                {category === 'menswear' ? 'MENSWEAR FIT GUIDE' : 'KIDS WEAR FIT & AGE GUIDE'}
              </p>
            </div>
          </div>

          <button
            id="size-guide-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chart Content */}
        <div className="mt-5 space-y-6">
          {category === 'menswear' ? (
            <div>
              <h4 className="text-xs font-serif font-bold text-slate-900 mb-3 flex items-center gap-1.5 uppercase tracking-wider">
                <CheckCircle2 className="w-4 h-4 text-slate-900" />
                <span>MENSWEAR SHIRTS, KURTAS & JACKETS (INCHES)</span>
              </h4>
              <div className="overflow-x-auto border border-slate-900">
                <table className="w-full text-xs text-left text-slate-900 font-mono">
                  <thead className="bg-slate-900 text-white uppercase font-bold text-[10px] tracking-wider">
                    <tr>
                      <th className="p-3 border-r border-slate-800">SIZE</th>
                      <th className="p-3 border-r border-slate-800">CHEST (INCHES)</th>
                      <th className="p-3 border-r border-slate-800">SHOULDER</th>
                      <th className="p-3">LENGTH</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-900">
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">S (Small)</td>
                      <td className="p-3 border-r border-slate-900">36" - 38"</td>
                      <td className="p-3 border-r border-slate-900">16.5"</td>
                      <td className="p-3">28"</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">M (Medium)</td>
                      <td className="p-3 border-r border-slate-900">38" - 40"</td>
                      <td className="p-3 border-r border-slate-900">17.5"</td>
                      <td className="p-3">29"</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">L (Large)</td>
                      <td className="p-3 border-r border-slate-900">40" - 42"</td>
                      <td className="p-3 border-r border-slate-900">18.5"</td>
                      <td className="p-3">30"</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">XL (Extra Large)</td>
                      <td className="p-3 border-r border-slate-900">42" - 44"</td>
                      <td className="p-3 border-r border-slate-900">19.5"</td>
                      <td className="p-3">31"</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">XXL (Double XL)</td>
                      <td className="p-3 border-r border-slate-900">44" - 46"</td>
                      <td className="p-3 border-r border-slate-900">20.5"</td>
                      <td className="p-3">32"</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div>
              <h4 className="text-xs font-serif font-bold text-slate-900 mb-3 flex items-center gap-1.5 uppercase tracking-wider">
                <CheckCircle2 className="w-4 h-4 text-slate-900" />
                <span>KIDS WEAR AGE & HEIGHT SIZING TABLE</span>
              </h4>
              <div className="overflow-x-auto border border-slate-900">
                <table className="w-full text-xs text-left text-slate-900 font-mono">
                  <thead className="bg-slate-900 text-white uppercase font-bold text-[10px] tracking-wider">
                    <tr>
                      <th className="p-3 border-r border-slate-800">SIZE TAG</th>
                      <th className="p-3 border-r border-slate-800">RECOMMENDED AGE</th>
                      <th className="p-3 border-r border-slate-800">HEIGHT (CM)</th>
                      <th className="p-3">CHEST (INCHES)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-900">
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">2Y - 3Y</td>
                      <td className="p-3 border-r border-slate-900">2 to 3 Years</td>
                      <td className="p-3 border-r border-slate-900">85 - 95 cm</td>
                      <td className="p-3">22"</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">4Y - 5Y</td>
                      <td className="p-3 border-r border-slate-900">4 to 5 Years</td>
                      <td className="p-3 border-r border-slate-900">100 - 110 cm</td>
                      <td className="p-3">24"</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">6Y - 7Y</td>
                      <td className="p-3 border-r border-slate-900">6 to 7 Years</td>
                      <td className="p-3 border-r border-slate-900">115 - 125 cm</td>
                      <td className="p-3">26"</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">8Y - 9Y</td>
                      <td className="p-3 border-r border-slate-900">8 to 9 Years</td>
                      <td className="p-3 border-r border-slate-900">130 - 138 cm</td>
                      <td className="p-3">28"</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="p-3 font-bold border-r border-slate-900">10Y - 12Y</td>
                      <td className="p-3 border-r border-slate-900">10 to 12 Years</td>
                      <td className="p-3 border-r border-slate-900">140 - 152 cm</td>
                      <td className="p-3">30"</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Measurement Advice Box */}
          <div className="bg-slate-50 border border-slate-900 p-4 text-xs text-slate-900 space-y-1 uppercase tracking-wider font-semibold">
            <span className="font-bold block">💡 PRO FITTING TIP:</span>
            <p>
              {language === 'hi'
                ? 'यदि आप दो साइज़ के बीच उलझन में हैं या बच्चों के लिए थोड़ा ढीला कम्फर्ट फिट चाहते हैं, तो हमेशा एक बड़ा साइज़ चुनें।'
                : 'If you fall between two sizes or prefer a relaxed comfort fit for children, we always recommend choosing the larger size.'}
            </p>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-900 flex justify-end">
          <button
            id="size-guide-understand-btn"
            onClick={onClose}
            className="bg-slate-900 text-white font-bold text-xs uppercase tracking-widest px-6 py-2.5 border border-slate-900 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            {language === 'hi' ? 'समझ गया' : 'GOT IT'}
          </button>
        </div>
      </div>
    </div>
  );
};
