import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  Tag, 
  ArrowRight, 
  Truck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { CartItem } from '../types';
import { PROMO_CODES } from '../data/products';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (cartItemId: string, delta: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onProceedToCheckout: (discountAmount: number, appliedCode: string) => void;
  language: 'en' | 'hi';
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  language
}) => {
  if (!isOpen) return null;

  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discountPercent: number; maxDiscount: number } | null>(null);
  const [promoError, setPromoError] = useState<string | null>(null);

  // Math Calculations
  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  
  let discountAmount = 0;
  if (appliedPromo) {
    discountAmount = Math.min((subtotal * appliedPromo.discountPercent) / 100, appliedPromo.maxDiscount);
  }

  const freeShippingThreshold = 999;
  const shippingFee = subtotal >= freeShippingThreshold || subtotal === 0 ? 0 : 70;
  const grandTotal = Math.max(0, subtotal - discountAmount + shippingFee);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = promoInput.trim().toUpperCase();
    if (PROMO_CODES[cleanCode]) {
      const codeInfo = PROMO_CODES[cleanCode];
      if (subtotal < codeInfo.minOrder) {
        setPromoError(`Minimum order value of ₹${codeInfo.minOrder} required for ${cleanCode}`);
        setAppliedPromo(null);
      } else {
        setAppliedPromo({
          code: cleanCode,
          discountPercent: codeInfo.discountPercent,
          maxDiscount: codeInfo.maxDiscount
        });
        setPromoError(null);
      }
    } else {
      setPromoError('Invalid Coupon Code. Try JANU10 or FESTIVE20');
      setAppliedPromo(null);
    }
  };

  const freeShippingRemaining = Math.max(0, freeShippingThreshold - subtotal);
  const freeShippingProgress = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 flex justify-end animate-fadeIn">
      <div className="bg-white w-full max-w-md h-full border-l border-slate-900 flex flex-col justify-between overflow-hidden relative">
        
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-900 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-5 h-5 text-white" />
            <h3 className="font-serif font-bold text-base tracking-widest uppercase">
              {language === 'hi' ? 'आपकी कार्ट (SHOPPING CART)' : 'SHOPPING CART'}
            </h3>
            <span className="bg-white text-slate-900 text-xs font-bold px-2 py-0.5 font-mono">
              {cartItems.reduce((a, b) => a + b.quantity, 0)}
            </span>
          </div>

          <button
            id="cart-drawer-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Indicator */}
        <div className="bg-slate-50 p-3 border-b border-slate-900 text-xs space-y-1.5">
          <div className="flex items-center justify-between text-slate-900 font-bold uppercase tracking-wider text-[10px]">
            <span className="flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-slate-900" />
              {freeShippingRemaining === 0
                ? (language === 'hi' ? 'मुफ्त डिलीवरी प्राप्त हुई!' : 'FREE Express Shipping Unlocked!')
                : (language === 'hi'
                    ? `मुफ्त डिलीवरी के लिए ₹${freeShippingRemaining} जोड़ें`
                    : `Add ₹${freeShippingRemaining} for FREE Express Shipping`)}
            </span>
            <span className="font-mono">{Math.round(freeShippingProgress)}%</span>
          </div>
          <div className="w-full bg-slate-200 h-1 rounded-none overflow-hidden">
            <div
              className="bg-slate-900 h-full transition-all duration-500"
              style={{ width: `${freeShippingProgress}%` }}
            />
          </div>
        </div>

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cartItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 border border-slate-900 flex items-center justify-center text-slate-900">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h4 className="font-serif font-bold text-slate-900 text-lg uppercase tracking-wider">
                {language === 'hi' ? 'कार्ट खाली है' : 'Cart is Empty'}
              </h4>
              <p className="text-slate-600 text-xs uppercase tracking-wider font-semibold max-w-xs">
                {language === 'hi'
                  ? 'जानू ट्रेंड्स मेन्सवेयर और किड्सवेयर संग्रह देखें और पसंदीदा कपड़े चुनें!'
                  : 'Explore Janu Trends Menswear & Kids Wear collection to add items.'}
              </p>
            </div>
          ) : (
            cartItems.map((item) => (
              <div
                key={item.id}
                className="bg-white p-3 border border-slate-900 flex gap-3 items-center justify-between"
              >
                <img
                  src={item.product.images[0]}
                  alt={item.product.title}
                  referrerPolicy="no-referrer"
                  className="w-16 h-20 object-cover object-top border border-slate-900 shrink-0"
                />

                <div className="flex-1 min-w-0 space-y-1">
                  <h4 className="font-serif font-bold text-slate-900 text-xs line-clamp-1 uppercase tracking-wider">
                    {language === 'hi' && item.product.titleHindi ? item.product.titleHindi : item.product.title}
                  </h4>
                  
                  <div className="flex items-center gap-2 text-[10px] text-slate-600 font-bold uppercase tracking-widest">
                    <span className="bg-slate-100 px-1.5 py-0.5 border border-slate-300">
                      SIZE: {item.selectedSize}
                    </span>
                    <span>•</span>
                    <span className="truncate">{item.selectedColor}</span>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="font-bold text-slate-900 text-sm font-mono">
                      ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                    </span>

                    {/* Quantity Selector */}
                    <div className="flex items-center border border-slate-900 bg-white overflow-hidden text-xs">
                      <button
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="px-2 py-0.5 hover:bg-slate-100 text-slate-900 cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 font-mono font-bold text-slate-900">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="px-2 py-0.5 hover:bg-slate-100 text-slate-900 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onRemoveItem(item.id)}
                  className="p-2 text-slate-400 hover:text-slate-900 transition-colors cursor-pointer shrink-0"
                  title="Remove item"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {cartItems.length > 0 && (
          <div className="p-5 border-t border-slate-900 bg-white space-y-4">
            
            {/* Promo Code Form */}
            <form onSubmit={handleApplyPromo} className="space-y-1.5">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value)}
                    placeholder="COUPON (e.g. JANU10)"
                    className="w-full bg-slate-50 border border-slate-900 py-2 pl-8 pr-3 text-xs font-bold uppercase text-slate-900 placeholder-slate-400 focus:outline-none"
                  />
                  <Tag className="w-3.5 h-3.5 text-slate-900 absolute left-2.5 top-3" />
                </div>

                <button
                  type="submit"
                  className="bg-slate-900 text-white text-xs font-bold uppercase tracking-widest px-4 border border-slate-900 hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Apply
                </button>
              </div>

              {appliedPromo && (
                <div className="flex items-center gap-1.5 text-[10px] text-emerald-800 font-bold uppercase tracking-widest bg-emerald-50 border border-emerald-800 p-2">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Coupon {appliedPromo.code} applied! Saved ₹{discountAmount}</span>
                </div>
              )}

              {promoError && (
                <div className="flex items-center gap-1.5 text-[10px] text-rose-800 font-bold uppercase tracking-widest bg-rose-50 border border-rose-800 p-2">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{promoError}</span>
                </div>
              )}
            </form>

            {/* Bill Summary */}
            <div className="space-y-2 text-xs uppercase tracking-wider font-semibold text-slate-700 border-t border-slate-900 pt-3">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono font-bold text-slate-900">₹{subtotal.toLocaleString('en-IN')}</span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-800 font-bold">
                  <span>Discount</span>
                  <span className="font-mono">- ₹{discountAmount.toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Shipping</span>
                <span className="font-mono font-bold text-slate-900">
                  {shippingFee === 0 ? <span className="text-emerald-800 uppercase">FREE</span> : `₹${shippingFee}`}
                </span>
              </div>

              <div className="flex justify-between text-sm font-serif font-bold text-slate-900 pt-2 border-t border-slate-900">
                <span>GRAND TOTAL</span>
                <span className="font-mono text-base">₹{grandTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Checkout Action */}
            <button
              id="cart-checkout-proceed-btn"
              onClick={() => onProceedToCheckout(discountAmount, appliedPromo?.code || '')}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 text-xs uppercase tracking-widest flex items-center justify-center gap-2 border border-slate-900 transition-all cursor-pointer"
            >
              <span>{language === 'hi' ? 'चेकआउट आगे बढ़ाएं' : 'PROCEED TO CHECKOUT'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
