import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, ChevronLeft, ChevronRight, ShieldCheck, Truck, RefreshCw } from 'lucide-react';
import { ProductCategory } from '../types';

import menswearHeroImg from '../assets/images/janu_menswear_hero_1784794633958.jpg';
import kidswearHeroImg from '../assets/images/janu_kidswear_hero_1784794653795.jpg';

interface HeroSliderProps {
  onSelectCategory: (cat: ProductCategory) => void;
  onOpenAiStylist: () => void;
  language: 'en' | 'hi';
}

export const HeroSlider: React.FC<HeroSliderProps> = ({
  onSelectCategory,
  onOpenAiStylist,
  language
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 'slide-menswear',
      image: menswearHeroImg,
      badge: language === 'hi' ? 'SS/26 मेन्सवेयर कलेक्शन' : 'SS/26 MENSWEAR COLLECTION',
      titleNumber: '01 / 02',
      title: language === 'hi' ? 'रॉयल स्टाइल और सिल्क कुर्ते' : 'Define The Modern Man.',
      subtitle: language === 'hi' ? 'ग्लोबल ट्रेंड्स और प्रीमियम सिल्क कॉटन फैब्रिक के साथ मेन्सवेयर संग्रह।' : 'Premium tailoring meets Indian utility. Our Menswear collection brings global trends with fine craftsmanship.',
      primaryBtnText: language === 'hi' ? 'एक्सप्लोर मेन्सवेयर' : 'Explore Menswear',
      category: 'menswear' as ProductCategory
    },
    {
      id: 'slide-kidswear',
      image: kidswearHeroImg,
      badge: language === 'hi' ? 'किड्स उत्सव स्पेशल 2026' : 'KIDSWEAR SPECIAL 2Y-14Y',
      titleNumber: '02 / 02',
      title: language === 'hi' ? 'मासूमों के लिए एथनिक ट्रेंड्स' : 'Playful Festive Trends.',
      subtitle: language === 'hi' ? '100% सॉफ्ट कॉटन एथनिक सूट, पार्टी फ्रॉक और किड्स जैकेट्स।' : 'Skin-friendly certified cotton ethnic sets, tuxedo party suits & cozy fleece hoodies for boys & girls.',
      primaryBtnText: language === 'hi' ? 'एक्सप्लोर किड्सवेयर' : 'Explore Kidswear',
      category: 'kidswear' as ProductCategory
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % slides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);

  const activeSlide = slides[currentSlide];

  return (
    <div className="relative bg-white border-b border-slate-900 mx-4 sm:mx-6 lg:mx-8 my-4 shadow-2xl">
      
      {/* Geometric Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 border border-slate-900">
        
        {/* Left Focus Column */}
        <div className="p-8 sm:p-12 lg:p-14 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-900 bg-white relative">
          <div className="space-y-8">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] border border-slate-900 px-3 py-1 text-slate-900">
                {activeSlide.badge}
              </span>
              <span className="text-xs font-mono font-bold text-slate-400">
                {activeSlide.titleNumber}
              </span>
            </div>

            <h1 className="text-4xl sm:text-6xl font-serif leading-tight uppercase font-extrabold text-slate-900 tracking-tight">
              {activeSlide.title}
            </h1>

            <p className="max-w-md text-xs sm:text-sm leading-relaxed text-slate-700 font-medium border-l-2 border-slate-900 pl-4">
              {activeSlide.subtitle}
            </p>

            <div className="pt-4 flex flex-wrap items-center gap-4">
              <button
                id={`hero-shop-btn-${activeSlide.category}`}
                onClick={() => onSelectCategory(activeSlide.category)}
                className="bg-slate-900 text-white px-8 py-4 text-xs font-bold uppercase tracking-widest hover:bg-slate-800 transition-all cursor-pointer flex items-center gap-3 border border-slate-900 shadow-md"
              >
                <span>{activeSlide.primaryBtnText}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-ai-stylist-btn"
                onClick={onOpenAiStylist}
                className="bg-white text-slate-900 px-6 py-4 text-xs font-bold uppercase tracking-widest border border-slate-900 hover:bg-slate-100 transition-all cursor-pointer flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>{language === 'hi' ? 'AI आउटफिट सलाह' : 'Ask AI Stylist'}</span>
              </button>
            </div>
          </div>

          {/* Micro Stat Rail */}
          <div className="mt-12 pt-6 border-t border-slate-900 grid grid-cols-2 gap-4">
            <div>
              <div className="text-2xl font-serif italic font-bold text-slate-900">100% Organic</div>
              <div className="text-[9px] uppercase tracking-widest font-bold text-slate-500">Cotton & Silk Fabric</div>
            </div>
            <div>
              <div className="text-2xl font-serif italic font-bold text-slate-900">Flat 50% OFF</div>
              <div className="text-[9px] uppercase tracking-widest font-bold text-slate-500">Festive Season Pricing</div>
            </div>
          </div>
        </div>

        {/* Right Geometric Image & Abstract Frame */}
        <div className="relative min-h-[360px] lg:min-h-[520px] bg-slate-100 flex items-center justify-center overflow-hidden">
          <img
            src={activeSlide.image}
            alt={activeSlide.title}
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover object-top filter saturate-[0.9] transition-all duration-700 hover:scale-105"
          />
          <div className="absolute inset-0 bg-slate-900/10 backdrop-blur-[1px]" />

          {/* Geometric Circle Badge Overlay */}
          <div className="absolute top-6 right-6 w-28 h-28 border border-white/90 rounded-full flex items-center justify-center p-3 text-center text-[9px] uppercase font-bold text-white bg-slate-900/60 backdrop-blur-md">
            Janu Trends Certified Quality
          </div>

          {/* Prev/Next Controls */}
          <div className="absolute bottom-6 right-6 flex space-x-2 z-20">
            <button
              id="hero-prev-slide-btn"
              onClick={prevSlide}
              className="w-10 h-10 bg-slate-900 text-white border border-slate-900 flex items-center justify-center hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Previous slide"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              id="hero-next-slide-btn"
              onClick={nextSlide}
              className="w-10 h-10 bg-slate-900 text-white border border-slate-900 flex items-center justify-center hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Next slide"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

      </div>

      {/* Bottom Info Rail (Geometric Balance Style) */}
      <div className="grid grid-cols-1 md:grid-cols-3 bg-slate-900 text-white text-[10px] font-bold uppercase tracking-widest py-4 px-6 border-x border-b border-slate-900 divide-y md:divide-y-0 md:divide-x divide-slate-800">
        <div className="flex items-center justify-center gap-2 py-2 md:py-0">
          <Truck className="w-4 h-4 text-slate-300" />
          <span>{language === 'hi' ? '₹999+ पर ऑल इंडिया फ्री डिलीवरी' : 'Free Express Shipping Over ₹999'}</span>
        </div>
        <div className="flex items-center justify-center gap-2 py-2 md:py-0">
          <RefreshCw className="w-4 h-4 text-slate-300" />
          <span>{language === 'hi' ? '15 दिन में आसान रिटर्न्स' : 'Easy 15-Day Hassle-Free Returns'}</span>
        </div>
        <div className="flex items-center justify-center gap-2 py-2 md:py-0">
          <ShieldCheck className="w-4 h-4 text-slate-300" />
          <span>{language === 'hi' ? 'भारत में निर्मित • शुद्ध कॉटन सिल्क' : 'Crafted in India • Pure Silk Cotton'}</span>
        </div>
      </div>

    </div>
  );
};
