import React, { useState } from 'react';
import { X, Sparkles, Send, ArrowRight, Bot, Loader2 } from 'lucide-react';
import { Product } from '../types';
import { PRODUCTS } from '../data/products';

interface AiStylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (p: Product) => void;
  language: 'en' | 'hi';
}

export const AiStylistModal: React.FC<AiStylistModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
  language
}) => {
  if (!isOpen) return null;

  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<string | null>(
    language === 'hi'
      ? 'नमस्ते! मैं जानू AI स्टाइल गुरु हूँ। मुझे बताएं कि आप किस अवसर (शादी, पार्टी, कैजुअल या गिफ्ट) के लिए कपड़े ढूँढ रहे हैं?'
      : 'Hello! I am your Janu AI Outfit Stylist. Tell me your occasion, budget, or family needs (e.g., "Kurta for wedding under ₹2000" or "Birthday suit for 5 year old boy")!'
  );
  const [recommendedProducts, setRecommendedProducts] = useState<Product[]>([
    PRODUCTS[0],
    PRODUCTS[6]
  ]);

  const quickPrompts = [
    language === 'hi' ? 'शादी के लिए पुरुषों का सिल्क कुर्ता' : 'Mens silk kurta for wedding',
    language === 'hi' ? '5 साल के बच्चे के लिए बर्थडे सूट' : 'Birthday party suit for 5yr boy',
    language === 'hi' ? 'कैजुअल स्लिम फिट कॉटन शर्ट्स' : 'Slim fit cotton casual shirts',
    language === 'hi' ? 'पापा-बेटे का मैचिंग एथनिक ऑउटफिट' : 'Father and son matching festive look'
  ];

  const handleAskAi = async (textToAsk?: string) => {
    const query = textToAsk || prompt;
    if (!query.trim() || loading) return;

    setLoading(true);
    try {
      const res = await fetch('/api/ai-stylist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userPrompt: query,
          language
        })
      });

      const data = await res.json();
      setAiAdvice(data.advice || 'Check out these top fashion picks from Janu Trends!');

      if (data.recommendedProductIds && Array.isArray(data.recommendedProductIds)) {
        const matched = PRODUCTS.filter(p => data.recommendedProductIds.includes(p.id));
        setRecommendedProducts(matched.length > 0 ? matched : [PRODUCTS[0], PRODUCTS[1]]);
      }
      setPrompt('');
    } catch (err) {
      console.error('Error fetching AI style advice:', err);
      setAiAdvice('Here are our top recommended styles for you from Janu Trends!');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 flex items-center justify-center p-3 sm:p-6 animate-fadeIn overflow-y-auto">
      <div className="bg-white max-w-2xl w-full my-auto border border-slate-900 overflow-hidden relative flex flex-col max-h-[88vh] shadow-lg">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-white text-slate-900 flex items-center justify-center border border-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-base tracking-widest uppercase">
                {language === 'hi' ? 'जानू AI स्टाइल गुरु' : 'JANU AI PERSONAL STYLIST'}
              </h3>
              <p className="text-[10px] uppercase tracking-widest text-slate-300">
                GEMINI AI • MENSWEAR & KIDS WEAR
              </p>
            </div>
          </div>

          <button
            id="ai-stylist-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* AI Response Card */}
          <div className="bg-slate-50 border border-slate-900 p-4 flex gap-3 text-xs sm:text-sm text-slate-900">
            <Bot className="w-5 h-5 text-slate-900 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-serif font-bold text-slate-900 block text-xs uppercase tracking-wider">
                JANU AI STYLIST ADVICE:
              </span>
              <p className="leading-relaxed text-slate-800 text-xs uppercase tracking-wider">
                {aiAdvice}
              </p>
            </div>
          </div>

          {/* Recommended Product Cards */}
          {recommendedProducts.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-serif font-bold text-xs uppercase tracking-wider text-slate-900 border-b border-slate-900 pb-1">
                {language === 'hi' ? 'AI द्वारा सुझाये गए उत्पाद' : 'RECOMMENDED MATCHES:'}
              </h4>
              <div className="grid grid-cols-2 gap-3">
                {recommendedProducts.map((prod) => (
                  <div
                    key={prod.id}
                    onClick={() => {
                      onSelectProduct(prod);
                      onClose();
                    }}
                    className="group bg-slate-50 p-3 border border-slate-900 hover:bg-slate-100 transition-all cursor-pointer flex gap-3 items-center"
                  >
                    <img
                      src={prod.images[0]}
                      alt={prod.title}
                      referrerPolicy="no-referrer"
                      className="w-14 h-16 object-cover object-top border border-slate-900 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <h5 className="font-bold text-xs text-slate-900 line-clamp-1 uppercase tracking-wider">
                        {language === 'hi' && prod.titleHindi ? prod.titleHindi : prod.title}
                      </h5>
                      <span className="font-mono font-bold text-xs text-slate-900 block mt-1">
                        ₹{prod.price.toLocaleString('en-IN')}
                      </span>
                      <span className="text-[10px] text-slate-900 font-bold flex items-center gap-1 mt-1 uppercase tracking-widest group-hover:line-through">
                        <span>VIEW DETAILS</span>
                        <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Starter Chips */}
          <div className="space-y-2 pt-2 border-t border-slate-900">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 block">
              {language === 'hi' ? 'त्वरित प्रश्न चुनें (Tap to ask):' : 'TAP A QUICK SUGGESTION:'}
            </span>
            <div className="flex flex-wrap gap-2">
              {quickPrompts.map((qp, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAskAi(qp)}
                  className="bg-white hover:bg-slate-900 hover:text-white text-slate-900 text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 border border-slate-900 transition-colors cursor-pointer"
                >
                  ✨ {qp}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Chat Input Footer */}
        <div className="p-4 border-t border-slate-900 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleAskAi();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={language === 'hi' ? 'जैसे: शादी के लिए 1500 में कुर्ता बताओ...' : 'Ask AI stylist (e.g. "Outfit for 6yo boy birthday")...'}
              className="flex-1 bg-slate-50 border border-slate-900 px-3 py-2.5 text-xs text-slate-900 uppercase tracking-wider focus:outline-none"
            />

            <button
              id="ai-stylist-send-btn"
              type="submit"
              disabled={loading || !prompt.trim()}
              className="bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white border border-slate-900 px-6 font-bold text-xs uppercase tracking-widest flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <>
                  <span>ASK</span>
                  <Send className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
