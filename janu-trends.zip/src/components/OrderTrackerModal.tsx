import React, { useState } from 'react';
import { X, Search, Truck } from 'lucide-react';
import { Order } from '../types';

interface OrderTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  recentOrders: Order[];
  language: 'en' | 'hi';
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({
  isOpen,
  onClose,
  recentOrders,
  language
}) => {
  if (!isOpen) return null;

  const [searchQuery, setSearchQuery] = useState('');
  const [activeOrder, setActiveOrder] = useState<Order | null>(
    recentOrders[0] || {
      id: 'JANU-849201',
      items: [],
      totalAmount: 1499,
      discountAmount: 150,
      shippingFee: 0,
      finalAmount: 1349,
      customerName: 'Jaan Mohammad Khan',
      customerPhone: '9876543210',
      customerEmail: 'jaan@gmail.com',
      address: '204 Green Park Main',
      pincode: '110016',
      city: 'New Delhi',
      state: 'Delhi',
      paymentMethod: 'upi',
      status: 'Shipped',
      createdAt: '22 Jul 2026',
      estimatedDelivery: '25 Jul 2026'
    }
  );

  const handleSearchOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const found = recentOrders.find(
      o => o.id.toLowerCase() === searchQuery.trim().toLowerCase() || o.customerPhone === searchQuery.trim()
    );
    if (found) {
      setActiveOrder(found);
    } else if (searchQuery.length > 3) {
      setActiveOrder({
        id: searchQuery.toUpperCase().startsWith('JANU-') ? searchQuery.toUpperCase() : `JANU-${searchQuery.toUpperCase()}`,
        items: [],
        totalAmount: 1999,
        discountAmount: 200,
        shippingFee: 0,
        finalAmount: 1799,
        customerName: 'Valued Customer',
        customerPhone: '9876543210',
        customerEmail: 'user@example.com',
        address: 'Main Street, City Center',
        pincode: '110001',
        city: 'Delhi',
        state: 'Delhi',
        paymentMethod: 'upi',
        status: 'Out for Delivery',
        createdAt: '21 Jul 2026',
        estimatedDelivery: 'Today by 6:00 PM'
      });
    }
  };

  const statusSteps = ['Ordered', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];
  const currentStepIndex = activeOrder ? statusSteps.indexOf(activeOrder.status) : 2;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 flex items-center justify-center p-3 sm:p-6 animate-fadeIn overflow-y-auto">
      <div className="bg-white max-w-xl w-full my-auto border border-slate-900 overflow-hidden relative shadow-lg">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-900">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-white" />
            <h3 className="font-serif font-bold text-base tracking-widest uppercase">
              {language === 'hi' ? 'लाइव ऑर्डर ट्रैकिंग' : 'TRACK ORDER STATUS'}
            </h3>
          </div>

          <button
            id="order-tracker-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          
          {/* Lookup Input */}
          <form onSubmit={handleSearchOrder} className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ENTER ORDER ID (e.g. JANU-849201)..."
                className="w-full bg-slate-50 border border-slate-900 py-2.5 pl-9 pr-3 text-xs font-bold uppercase text-slate-900 focus:outline-none"
              />
              <Search className="w-4 h-4 text-slate-900 absolute left-3 top-3" />
            </div>

            <button
              type="submit"
              className="bg-slate-900 text-white font-bold px-5 text-xs uppercase tracking-widest border border-slate-900 hover:bg-slate-800 transition-colors cursor-pointer"
            >
              TRACK
            </button>
          </form>

          {activeOrder && (
            <div className="space-y-6">
              
              {/* Order Meta Box */}
              <div className="bg-slate-50 p-4 border border-slate-900 flex items-center justify-between text-xs font-bold uppercase tracking-wider">
                <div>
                  <span className="text-slate-500 block">ORDER NUMBER</span>
                  <span className="font-mono text-slate-900 text-sm">{activeOrder.id}</span>
                </div>

                <div className="text-right">
                  <span className="text-slate-500 block">EXPECTED DELIVERY</span>
                  <span className="font-mono text-slate-900 text-xs">{activeOrder.estimatedDelivery}</span>
                </div>
              </div>

              {/* Status Timeline */}
              <div className="space-y-4">
                <h4 className="font-serif font-bold text-slate-900 text-xs uppercase tracking-wider border-b border-slate-900 pb-2">
                  LIVE STATUS TIMELINE
                </h4>

                <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-900">
                  {statusSteps.map((stepName, idx) => {
                    const isPassed = idx <= currentStepIndex;
                    const isCurrent = idx === currentStepIndex;

                    return (
                      <div key={stepName} className="relative flex items-center gap-3 text-xs">
                        <div
                          className={`absolute -left-6 w-5 h-5 font-mono font-bold text-[10px] flex items-center justify-center transition-all ${
                            isPassed
                              ? 'bg-slate-900 text-white border border-slate-900'
                              : 'bg-white text-slate-400 border border-slate-300'
                          }`}
                        >
                          {isPassed ? '✓' : idx + 1}
                        </div>

                        <div>
                          <span className={`font-bold uppercase tracking-wider block ${isCurrent ? 'text-slate-900 text-sm line-through' : isPassed ? 'text-slate-900' : 'text-slate-400'}`}>
                            {stepName}
                          </span>
                          {isCurrent && (
                            <span className="text-[10px] text-slate-600 font-semibold uppercase tracking-wider">
                              Package in transit with Janu Express Courier.
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Delivery Details */}
              <div className="bg-slate-50 p-4 border border-slate-900 text-xs space-y-1 font-semibold uppercase tracking-wider">
                <span className="font-bold text-slate-900 block">SHIPPING ADDRESS:</span>
                <p className="text-slate-700">
                  {activeOrder.customerName} ({activeOrder.customerPhone})
                </p>
                <p className="text-slate-600">
                  {activeOrder.address}, {activeOrder.pincode}
                </p>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
