import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  X, 
  CheckCircle2, 
  CreditCard, 
  QrCode, 
  DollarSign, 
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Printer
} from 'lucide-react';
import { CartItem, Order } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  discountAmount: number;
  appliedCode: string;
  onOrderSuccess: (order: Order) => void;
  language: 'en' | 'hi';
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  discountAmount,
  appliedCode,
  onOrderSuccess,
  language
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('Delhi');
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'cod' | 'card' | 'netbanking'>('upi');
  const [upiId, setUpiId] = useState('');
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const shippingFee = subtotal >= 999 || subtotal === 0 ? 0 : 70;
  const grandTotal = Math.max(0, subtotal - discountAmount + shippingFee);

  const handleNextToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !address || !pincode) {
      alert(language === 'hi' ? 'कृपया सभी आवश्यक फ़ील्ड भरें' : 'Please fill all required delivery address fields.');
      return;
    }
    setStep(2);
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();

    const newOrder: Order = {
      id: `JANU-${Math.floor(100000 + Math.random() * 900000)}`,
      items: [...cartItems],
      totalAmount: subtotal,
      discountAmount,
      shippingFee,
      finalAmount: grandTotal,
      customerName,
      customerPhone,
      customerEmail,
      address,
      pincode,
      city,
      state,
      paymentMethod,
      paymentDetails: paymentMethod === 'upi' ? upiId || 'janutrends@upi' : 'Cash on Delivery',
      status: 'Ordered',
      createdAt: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
      estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
    };

    setCreatedOrder(newOrder);
    onOrderSuccess(newOrder);
    setStep(3);

    // Launch celebratory confetti
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 flex items-center justify-center p-3 sm:p-6 animate-fadeIn overflow-y-auto">
      <div className="bg-white max-w-2xl w-full my-auto border border-slate-900 overflow-hidden relative shadow-lg">
        
        {/* Header Bar */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-900">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-white" />
            <h3 className="font-serif font-bold text-base tracking-widest uppercase">
              {step === 3 
                ? (language === 'hi' ? 'ऑर्डर कन्फर्म हुआ!' : 'ORDER CONFIRMED')
                : (language === 'hi' ? 'सुरक्षित चेकआउट' : 'CHECKOUT - JANU TRENDS')}
            </h3>
          </div>

          <button
            id="checkout-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Multi-step Breadcrumb */}
        {step !== 3 && (
          <div className="flex items-center justify-center bg-slate-50 py-3 px-4 border-b border-slate-900 text-xs font-bold uppercase tracking-widest text-slate-900 gap-6">
            <span className={`flex items-center gap-1.5 ${step >= 1 ? 'text-slate-900' : 'text-slate-400'}`}>
              <span className="w-5 h-5 bg-slate-900 text-white text-[10px] flex items-center justify-center">1</span>
              <span>DELIVERY ADDRESS</span>
            </span>
            <span>→</span>
            <span className={`flex items-center gap-1.5 ${step >= 2 ? 'text-slate-900' : 'text-slate-400'}`}>
              <span className="w-5 h-5 bg-slate-900 text-white text-[10px] flex items-center justify-center">2</span>
              <span>PAYMENT OPTION</span>
            </span>
          </div>
        )}

        {/* Content Body */}
        <div className="p-6 sm:p-8 max-h-[80vh] overflow-y-auto">
          
          {/* STEP 1: Address Details */}
          {step === 1 && (
            <form onSubmit={handleNextToPayment} className="space-y-5">
              <h4 className="font-serif font-bold text-slate-900 text-sm uppercase tracking-wider border-b border-slate-900 pb-2">
                {language === 'hi' ? 'डिलीवरी पता भरें' : 'SHIPPING & CONTACT DETAILS'}
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block mb-1">
                    FULL NAME *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Jaan Mohammad Khan"
                    className="w-full bg-slate-50 border border-slate-900 px-3 py-2 text-xs text-slate-900 uppercase tracking-wider focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block mb-1">
                    MOBILE PHONE NUMBER *
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. 9876543210"
                    className="w-full bg-slate-50 border border-slate-900 px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block mb-1">
                  EMAIL ADDRESS (FOR RECEIPT)
                </label>
                <input
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="e.g. jaan@gmail.com"
                  className="w-full bg-slate-50 border border-slate-900 px-3 py-2 text-xs text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block mb-1">
                  FULL ADDRESS *
                </label>
                <textarea
                  rows={2}
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Flat No 204, Green Avenue, Main Market"
                  className="w-full bg-slate-50 border border-slate-900 px-3 py-2 text-xs text-slate-900 uppercase tracking-wider focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block mb-1">
                    PINCODE *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value)}
                    placeholder="110001"
                    className="w-full bg-slate-50 border border-slate-900 px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block mb-1">
                    CITY
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Delhi"
                    className="w-full bg-slate-50 border border-slate-900 px-3 py-2 text-xs text-slate-900 uppercase focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block mb-1">
                    STATE
                  </label>
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    placeholder="Delhi"
                    className="w-full bg-slate-50 border border-slate-900 px-3 py-2 text-xs text-slate-900 uppercase focus:outline-none"
                  />
                </div>
              </div>

              {/* Order Amount Preview */}
              <div className="bg-slate-50 p-3.5 border border-slate-900 flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-900">
                <span>TOTAL PAYABLE:</span>
                <span className="font-mono text-sm">₹{grandTotal.toLocaleString('en-IN')}</span>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  id="checkout-step1-next-btn"
                  type="submit"
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-6 py-3 text-xs uppercase tracking-widest flex items-center gap-2 border border-slate-900 cursor-pointer transition-colors"
                >
                  <span>{language === 'hi' ? 'भुगतान पर जाएं' : 'PROCEED TO PAYMENT'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: Payment Option Selection */}
          {step === 2 && (
            <form onSubmit={handlePlaceOrder} className="space-y-5">
              <h4 className="font-serif font-bold text-slate-900 text-sm uppercase tracking-wider border-b border-slate-900 pb-2">
                {language === 'hi' ? 'भुगतान का तरीका चुनें' : 'SELECT PAYMENT METHOD'}
              </h4>

              <div className="space-y-3">
                
                {/* UPI */}
                <label className={`flex items-start gap-3 p-4 border cursor-pointer transition-all ${
                  paymentMethod === 'upi' ? 'bg-slate-900 text-white border-slate-900' : 'bg-white border-slate-900 text-slate-900'
                }`}>
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'upi'}
                    onChange={() => setPaymentMethod('upi')}
                    className="mt-1 accent-slate-900"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider">
                      <QrCode className="w-4 h-4" />
                      <span>INSTANT UPI / GOOGLE PAY / PHONEPE</span>
                    </div>
                    <p className="text-[10px] uppercase tracking-wider opacity-80 mt-0.5">
                      Fastest delivery & zero transaction fees
                    </p>

                    {paymentMethod === 'upi' && (
                      <div className="mt-3">
                        <input
                          type="text"
                          value={upiId}
                          onChange={(e) => setUpiId(e.target.value)}
                          placeholder="ENTER UPI ID (e.g. 9876543210@paytm)"
                          className="w-full bg-white text-slate-900 border border-slate-900 px-3 py-2 text-xs uppercase focus:outline-none"
                        />
                      </div>
                    )}
                  </div>
                </label>

                {/* Cash on Delivery */}
                <label className={`flex items-start gap-3 p-4 border cursor-pointer transition-all ${
                  paymentMethod === 'cod' ? 'bg-slate-900 text-white border-slate-900' : 'bg-white border-slate-900 text-slate-900'
                }`}>
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'cod'}
                    onChange={() => setPaymentMethod('cod')}
                    className="mt-1 accent-slate-900"
                  />
                  <div>
                    <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider">
                      <DollarSign className="w-4 h-4" />
                      <span>CASH ON DELIVERY (COD)</span>
                    </div>
                    <p className="text-[10px] uppercase tracking-wider opacity-80 mt-0.5">
                      Pay cash to delivery executive at doorstep
                    </p>
                  </div>
                </label>

                {/* Credit / Debit Card */}
                <label className={`flex items-start gap-3 p-4 border cursor-pointer transition-all ${
                  paymentMethod === 'card' ? 'bg-slate-900 text-white border-slate-900' : 'bg-white border-slate-900 text-slate-900'
                }`}>
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'card'}
                    onChange={() => setPaymentMethod('card')}
                    className="mt-1 accent-slate-900"
                  />
                  <div>
                    <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider">
                      <CreditCard className="w-4 h-4" />
                      <span>CREDIT / DEBIT CARD</span>
                    </div>
                  </div>
                </label>

              </div>

              {/* Order Final Summary */}
              <div className="bg-slate-50 p-4 border border-slate-900 space-y-1.5 text-xs font-bold uppercase tracking-wider text-slate-900">
                <div className="flex justify-between">
                  <span>ITEMS TOTAL:</span>
                  <span className="font-mono">₹{subtotal.toLocaleString('en-IN')}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-800">
                    <span>COUPON SAVINGS:</span>
                    <span className="font-mono">- ₹{discountAmount.toLocaleString('en-IN')}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-serif pt-2 border-t border-slate-900">
                  <span>AMOUNT PAYABLE:</span>
                  <span className="font-mono">₹{grandTotal.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs font-bold uppercase tracking-widest text-slate-900 hover:line-through flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>BACK</span>
                </button>

                <button
                  id="place-order-final-btn"
                  type="submit"
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-8 py-3.5 text-xs uppercase tracking-widest border border-slate-900 flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <span>{language === 'hi' ? 'ऑर्डर कन्फर्म करें' : 'CONFIRM & PLACE ORDER'}</span>
                  <CheckCircle2 className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: Order Confirmation */}
          {step === 3 && createdOrder && (
            <div className="text-center space-y-6 py-4">
              <div className="w-16 h-16 border-2 border-slate-900 text-slate-900 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-2xl font-serif font-bold text-slate-900 uppercase tracking-wider">
                  {language === 'hi' ? 'आपका ऑर्डर सफलता से बुक हुआ!' : 'ORDER CONFIRMED'}
                </h3>
                <p className="text-xs font-bold uppercase tracking-widest text-slate-600 mt-2">
                  ORDER ID: <span className="font-mono text-slate-900">{createdOrder.id}</span>
                </p>
              </div>

              {/* Order Info Cards */}
              <div className="bg-slate-50 p-5 border border-slate-900 text-xs text-left space-y-3 uppercase tracking-wider font-semibold">
                <div className="flex justify-between pb-2 border-b border-slate-900 font-bold text-slate-900">
                  <span>ESTIMATED DELIVERY:</span>
                  <span className="font-mono">{createdOrder.estimatedDelivery}</span>
                </div>
                <div>
                  <span className="font-bold text-slate-900 block">DELIVER TO:</span>
                  <span className="text-slate-900 font-bold">{createdOrder.customerName} ({createdOrder.customerPhone})</span>
                  <p className="text-slate-600 mt-0.5">{createdOrder.address}, {createdOrder.pincode}</p>
                </div>
                <div className="pt-2 border-t border-slate-900 flex justify-between font-serif font-bold text-sm text-slate-900">
                  <span>TOTAL PAID:</span>
                  <span className="font-mono">₹{createdOrder.finalAmount.toLocaleString('en-IN')} ({createdOrder.paymentMethod.toUpperCase()})</span>
                </div>
              </div>

              <div className="flex justify-center gap-4 pt-2">
                <button
                  id="order-confirm-print-btn"
                  onClick={() => window.print()}
                  className="bg-white hover:bg-slate-100 text-slate-900 font-bold border border-slate-900 px-5 py-3 text-xs uppercase tracking-widest flex items-center gap-2 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>PRINT RECEIPT</span>
                </button>

                <button
                  id="order-confirm-done-btn"
                  onClick={onClose}
                  className="bg-slate-900 text-white font-bold px-6 py-3 text-xs uppercase tracking-widest hover:bg-slate-800 border border-slate-900 transition-colors cursor-pointer"
                >
                  CONTINUE SHOPPING
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
