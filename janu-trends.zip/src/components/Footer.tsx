import React, { useState } from 'react';
import { 
  Shirt, 
  PhoneCall, 
  Mail, 
  MapPin, 
  Send, 
  CheckCircle2, 
  ShieldCheck, 
  Truck, 
  RefreshCw,
  MessageCircle
} from 'lucide-react';
import { ProductCategory } from '../types';

interface FooterProps {
  onSelectCategory: (cat: 'all' | ProductCategory) => void;
  openOrderTracker: () => void;
  openAiStylist: () => void;
  language: 'en' | 'hi';
}

export const Footer: React.FC<FooterProps> = ({
  onSelectCategory,
  openOrderTracker,
  openAiStylist,
  language
}) => {
  const [emailInput, setEmailInput] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailInput.includes('@')) {
      setSubscribed(true);
      setEmailInput('');
      setTimeout(() => setSubscribed(false), 4000);
    }
  };

  return (
    <footer className="bg-slate-950 text-slate-300 pt-12 pb-8 border-t border-amber-900/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Top Brand Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Col 1: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center text-slate-950 font-black shadow-md">
                <Shirt className="w-6 h-6" />
              </div>
              <span className="text-2xl font-black text-white tracking-tight uppercase">
                JANU <span className="text-amber-500">TRENDS</span>
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              {language === 'hi'
                ? 'जानू ट्रेंड्स - पुरुषों और बच्चों के लिए प्रीमियम सिल्क कुर्ते, स्लिम-फिट शर्ट्स, जीन्स, पार्टी सूट और फेस्टिव वियर का विश्वसनीय स्टोर।'
                : 'Janu Trends - Premium destination for Menswear & Kids Wear. Quality fabrics, fine embroidery, fast shipping, and unbeatable prices.'}
            </p>

            <div className="pt-1 flex flex-wrap gap-2">
              <a
                href="https://wa.me/919876543210"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition-colors cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Helpline</span>
              </a>

              <a
                href="tel:+919876543210"
                className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs px-3.5 py-2 rounded-xl transition-colors cursor-pointer border border-amber-500/20"
              >
                <PhoneCall className="w-4 h-4" />
                <span>+91 98765 43210</span>
              </a>
            </div>
          </div>

          {/* Col 2: Menswear Links */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-white text-xs uppercase tracking-wider text-amber-400">
              {language === 'hi' ? 'मेन्सवेयर (Menswear)' : 'Menswear Collection'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => onSelectCategory('menswear')} className="hover:text-amber-300 transition-colors cursor-pointer">
                  Silk Kurta Sets
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('menswear')} className="hover:text-amber-300 transition-colors cursor-pointer">
                  Casual & Formal Shirts
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('menswear')} className="hover:text-amber-300 transition-colors cursor-pointer">
                  Party Blazers & Nehru Jackets
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('menswear')} className="hover:text-amber-300 transition-colors cursor-pointer">
                  Stretch Denim Jeans & Cargos
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Kids Wear Links */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-white text-xs uppercase tracking-wider text-amber-400">
              {language === 'hi' ? 'किड्सवेयर (Kids Wear)' : 'Kids Wear Collection'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => onSelectCategory('kidswear')} className="hover:text-amber-300 transition-colors cursor-pointer">
                  Boys Kurta Dhoti Sets
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('kidswear')} className="hover:text-amber-300 transition-colors cursor-pointer">
                  Boys Party Tuxedo Suits
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('kidswear')} className="hover:text-amber-300 transition-colors cursor-pointer">
                  Girls Party Frocks & Gowns
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('kidswear')} className="hover:text-amber-300 transition-colors cursor-pointer">
                  Kids Fleece Hoodies & Jackets
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Newsletter & Offers */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-white text-xs uppercase tracking-wider text-amber-400">
              {language === 'hi' ? 'विशेष डिस्काउंट पाएं' : 'Get Exclusive Discounts'}
            </h4>
            <p className="text-xs text-slate-400">
              Subscribe for VIP festive coupon codes & new arrival alerts.
            </p>

            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="flex">
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="Your Email..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-l-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-2 rounded-r-xl transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>

              {subscribed && (
                <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Subscribed! Use code JANU10 for 10% OFF</span>
                </div>
              )}
            </form>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>© 2026 Janu Trends Inc. All rights reserved. Menswear & Kids Wear Store.</p>
          <div className="flex items-center gap-4">
            <span>UPI Accept</span>
            <span>•</span>
            <span>COD Available</span>
            <span>•</span>
            <span>Fast Express Delivery</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
