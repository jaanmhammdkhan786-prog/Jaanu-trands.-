import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Heart, 
  Search, 
  Sparkles, 
  Truck, 
  Menu, 
  X, 
  Globe, 
  Shirt, 
  Tag
} from 'lucide-react';
import { ProductCategory } from '../types';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  activeCategory: 'all' | ProductCategory;
  setActiveCategory: (cat: 'all' | ProductCategory) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  openCart: () => void;
  openWishlist: () => void;
  openOrderTracker: () => void;
  openAiStylist: () => void;
  language: 'en' | 'hi';
  setLanguage: (lang: 'en' | 'hi') => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  wishlistCount,
  activeCategory,
  setActiveCategory,
  searchQuery,
  setSearchQuery,
  openCart,
  openWishlist,
  openOrderTracker,
  openAiStylist,
  language,
  setLanguage
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-900 shadow-xs">
      {/* Top Geometric Announcement Ticker */}
      <div className="bg-slate-900 text-slate-100 text-xs py-2 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-3 text-center sm:text-left overflow-hidden">
            <span className="border border-slate-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-100 shrink-0">
              {language === 'hi' ? 'विशेष ऑफर' : 'SS/26 FESTIVE'}
            </span>
            <p className="truncate text-xs font-medium text-slate-300">
              {language === 'hi'
                ? '🎁 कोड JANU10 से पाएँ 10% छूट | ₹999 पर मुफ्त एक्सप्रेस डिलीवरी'
                : '🎁 Use code JANU10 for 10% OFF | Free Express Delivery on orders over ₹999'}
            </p>
          </div>

          <div className="flex items-center gap-4 shrink-0 text-[10px] uppercase font-bold tracking-widest text-slate-300">
            <button 
              id="header-track-order-btn"
              onClick={openOrderTracker}
              className="hover:line-through flex items-center gap-1 transition-all cursor-pointer"
            >
              <Truck className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'ऑर्डर ट्रैक' : 'Track Order'}</span>
            </button>
            <span className="text-slate-600">|</span>
            <button 
              id="header-lang-toggle-btn"
              onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
              className="hover:line-through flex items-center gap-1.5 border border-slate-700 px-2 py-0.5 cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-slate-300" />
              <span>{language === 'en' ? 'हिन्दी' : 'English'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between gap-4">
          
          {/* Mobile Menu & Left Nav Links */}
          <div className="flex items-center gap-6">
            <button
              id="header-mobile-menu-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-1.5 border border-slate-900 text-slate-900 hover:bg-slate-900 hover:text-white transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            {/* Desktop Category Navigation */}
            <div className="hidden lg:flex items-center space-x-6 text-xs font-bold uppercase tracking-widest text-slate-900">
              <button
                id="nav-cat-all"
                onClick={() => setActiveCategory('all')}
                className={`transition-all cursor-pointer ${
                  activeCategory === 'all'
                    ? 'line-through decoration-slate-900 text-slate-900 font-extrabold'
                    : 'hover:line-through opacity-70 hover:opacity-100'
                }`}
              >
                {language === 'hi' ? 'सभी कपड़े' : 'All Catalog'}
              </button>

              <button
                id="nav-cat-menswear"
                onClick={() => setActiveCategory('menswear')}
                className={`transition-all cursor-pointer ${
                  activeCategory === 'menswear'
                    ? 'line-through decoration-slate-900 text-slate-900 font-extrabold'
                    : 'hover:line-through opacity-70 hover:opacity-100'
                }`}
              >
                {language === 'hi' ? 'मेन्सवेयर' : 'Menswear'}
              </button>

              <button
                id="nav-cat-kidswear"
                onClick={() => setActiveCategory('kidswear')}
                className={`transition-all cursor-pointer ${
                  activeCategory === 'kidswear'
                    ? 'line-through decoration-slate-900 text-slate-900 font-extrabold'
                    : 'hover:line-through opacity-70 hover:opacity-100'
                }`}
              >
                {language === 'hi' ? 'किड्सवेयर' : 'Kidswear'}
              </button>
            </div>
          </div>

          {/* Center Brand Title (Geometric Balance Style) */}
          <a href="#" className="text-2xl sm:text-3xl font-serif tracking-tighter italic font-black text-slate-900 uppercase text-center hover:opacity-80 transition-opacity">
            JANU <span className="not-italic font-sans font-bold text-slate-900">TRENDS</span>
          </a>

          {/* Right Action Menu */}
          <div className="flex items-center space-x-3 sm:space-x-5 text-xs font-bold uppercase tracking-widest text-slate-900">
            
            {/* AI Stylist */}
            <button
              id="header-ai-stylist-btn"
              onClick={openAiStylist}
              className="hidden sm:flex items-center gap-1.5 border border-slate-900 px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider hover:bg-slate-900 hover:text-white transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'AI गुरु' : 'AI Stylist'}</span>
            </button>

            {/* Wishlist Button */}
            <button
              id="header-wishlist-btn"
              onClick={openWishlist}
              className="relative p-1.5 hover:line-through cursor-pointer flex items-center gap-1"
              title="Wishlist"
            >
              <Heart className="w-4 h-4 text-slate-900" />
              <span className="hidden md:inline text-xs">{wishlistCount > 0 ? `(${wishlistCount})` : ''}</span>
              {wishlistCount > 0 && (
                <span className="md:hidden absolute -top-1 -right-1 w-4 h-4 bg-slate-900 text-white text-[9px] font-bold flex items-center justify-center border border-white">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              id="header-cart-btn"
              onClick={openCart}
              className="bg-slate-900 text-white px-3.5 py-2 text-xs font-bold uppercase tracking-widest hover:bg-slate-800 transition-all cursor-pointer flex items-center gap-2 border border-slate-900"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-white" />
              <span>{language === 'hi' ? 'कार्ट' : 'Cart'} ({cartCount})</span>
            </button>

          </div>
        </div>

        {/* Search Bar Row */}
        <div className="mt-3 relative max-w-xl mx-auto">
          <input
            id="header-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'hi' ? 'खोजें: कुर्ता, शर्ट्स, सूट, किड्स वियर...' : 'SEARCH catalog: Kurta, Silk Shirts, Kids Suits, Denim...'}
            className="w-full bg-slate-50 border border-slate-900 px-4 py-2 text-xs font-bold tracking-wider text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white uppercase"
          />
          <Search className="w-4 h-4 text-slate-900 absolute right-3.5 top-2.5" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-10 top-2.5 text-slate-400 hover:text-slate-900 text-xs font-bold"
            >
              CLEAR
            </button>
          )}
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-slate-900 px-6 py-6 space-y-4 animate-fadeIn">
          <div className="flex flex-col space-y-3 text-xs font-bold uppercase tracking-widest text-slate-900">
            <button
              onClick={() => { setActiveCategory('all'); setMobileMenuOpen(false); }}
              className={`text-left py-1 ${activeCategory === 'all' ? 'line-through font-black' : 'hover:line-through'}`}
            >
              {language === 'hi' ? 'सभी कलेक्शन (All Catalog)' : 'All Catalog'}
            </button>
            <button
              onClick={() => { setActiveCategory('menswear'); setMobileMenuOpen(false); }}
              className={`text-left py-1 ${activeCategory === 'menswear' ? 'line-through font-black' : 'hover:line-through'}`}
            >
              {language === 'hi' ? 'मेन्सवेयर (Menswear)' : 'Menswear Collection'}
            </button>
            <button
              onClick={() => { setActiveCategory('kidswear'); setMobileMenuOpen(false); }}
              className={`text-left py-1 ${activeCategory === 'kidswear' ? 'line-through font-black' : 'hover:line-through'}`}
            >
              {language === 'hi' ? 'किड्सवेयर (Kidswear)' : 'Kidswear Collection'}
            </button>
          </div>

          <div className="pt-4 border-t border-slate-900 space-y-2">
            <button
              onClick={() => { openAiStylist(); setMobileMenuOpen(false); }}
              className="w-full border border-slate-900 bg-slate-900 text-white py-3 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>{language === 'hi' ? 'Janu AI स्टाइल एडवाइजर' : 'Janu AI Personal Stylist'}</span>
            </button>
            
            <button
              onClick={() => { openOrderTracker(); setMobileMenuOpen(false); }}
              className="w-full border border-slate-900 bg-white text-slate-900 py-3 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2"
            >
              <Truck className="w-4 h-4" />
              <span>{language === 'hi' ? 'ऑर्डर स्टेटस ट्रैक करें' : 'Track Existing Order'}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
