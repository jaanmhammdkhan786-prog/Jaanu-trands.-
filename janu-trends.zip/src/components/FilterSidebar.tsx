import React from 'react';
import { RotateCcw, SlidersHorizontal } from 'lucide-react';
import { FilterState, ProductCategory, SubCategory } from '../types';

interface FilterSidebarProps {
  filterState: FilterState;
  setFilterState: React.Dispatch<React.SetStateAction<FilterState>>;
  totalResults: number;
  language: 'en' | 'hi';
}

export const FilterSidebar: React.FC<FilterSidebarProps> = ({
  filterState,
  setFilterState,
  totalResults,
  language
}) => {
  const handleCategoryChange = (cat: 'all' | ProductCategory) => {
    setFilterState(prev => ({
      ...prev,
      category: cat,
      subcategories: []
    }));
  };

  const handleSubcategoryToggle = (sub: SubCategory) => {
    setFilterState(prev => {
      const exists = prev.subcategories.includes(sub);
      return {
        ...prev,
        subcategories: exists
          ? prev.subcategories.filter(s => s !== sub)
          : [...prev.subcategories, sub]
      };
    });
  };

  const handleSizeToggle = (sz: string) => {
    setFilterState(prev => {
      const exists = prev.sizes.includes(sz);
      return {
        ...prev,
        sizes: exists ? prev.sizes.filter(s => s !== sz) : [...prev.sizes, sz]
      };
    });
  };

  const resetFilters = () => {
    setFilterState({
      searchQuery: '',
      category: 'all',
      subcategories: [],
      priceRange: [0, 6000],
      sizes: [],
      colors: [],
      sortOption: 'featured',
      discountOnly: false,
      inStockOnly: false
    });
  };

  const subcategoryList: { id: SubCategory; label: string; cat: ProductCategory }[] = [
    { id: 'mens_ethnic', label: 'Mens Ethnic Kurtas', cat: 'menswear' },
    { id: 'mens_shirts', label: 'Mens Shirts & Tees', cat: 'menswear' },
    { id: 'mens_jackets', label: 'Mens Blazers & Jackets', cat: 'menswear' },
    { id: 'mens_bottoms', label: 'Mens Jeans & Pants', cat: 'menswear' },
    { id: 'kids_ethnic', label: 'Boys Ethnic Sets', cat: 'kidswear' },
    { id: 'kids_sets', label: 'Boys Party Suits & Sets', cat: 'kidswear' },
    { id: 'kids_girls', label: 'Girls Party Dresses', cat: 'kidswear' },
    { id: 'kids_jackets', label: 'Kids Hoodies & Winter', cat: 'kidswear' },
  ];

  const visibleSubcategories = subcategoryList.filter(s => 
    filterState.category === 'all' || s.cat === filterState.category
  );

  const availableSizes = filterState.category === 'kidswear'
    ? ['2Y-3Y', '4Y-5Y', '6Y-7Y', '8Y-9Y', '10Y-12Y']
    : ['S', 'M', 'L', 'XL', 'XXL', '38', '40', '42'];

  return (
    <div className="bg-white border border-slate-900 p-6 space-y-6 shadow-sm">
      
      {/* Title Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-900">
        <div className="flex items-center gap-2 text-slate-900 font-serif font-bold text-sm uppercase tracking-wider">
          <SlidersHorizontal className="w-4 h-4 text-slate-900" />
          <span>{language === 'hi' ? 'फ़िल्टर (FILTERS)' : 'FILTERS & SORT'}</span>
          <span className="text-[10px] font-sans font-bold text-slate-400">({totalResults})</span>
        </div>

        <button
          id="filter-reset-btn"
          onClick={resetFilters}
          className="text-slate-900 hover:line-through text-xs font-bold uppercase tracking-widest flex items-center gap-1 cursor-pointer"
        >
          <RotateCcw className="w-3 h-3" />
          <span>{language === 'hi' ? 'रीसेट' : 'CLEAR'}</span>
        </button>
      </div>

      {/* Sort By Dropdown */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block">
          {language === 'hi' ? 'क्रमानुसार (SORT BY):' : 'SORT BY:'}
        </label>
        <select
          id="filter-sort-select"
          value={filterState.sortOption}
          onChange={(e: any) => setFilterState(prev => ({ ...prev, sortOption: e.target.value }))}
          className="w-full bg-slate-50 border border-slate-900 px-3 py-2 text-xs font-bold uppercase tracking-wider text-slate-900 focus:outline-none cursor-pointer"
        >
          <option value="featured">Featured Collection</option>
          <option value="price-low-high">Price: Low to High</option>
          <option value="price-high-low">Price: High to Low</option>
          <option value="rating">Highest Customer Rating</option>
          <option value="discount">Max Discount %</option>
        </select>
      </div>

      {/* Category Selection Tabs */}
      <div className="space-y-2">
        <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block">
          {language === 'hi' ? 'मुख्य श्रेणी (CATEGORY):' : 'MAIN CATEGORY:'}
        </label>
        <div className="grid grid-cols-3 gap-1 bg-slate-100 border border-slate-900 p-1">
          <button
            onClick={() => handleCategoryChange('all')}
            className={`py-2 text-[10px] font-bold uppercase tracking-widest transition-all cursor-pointer ${
              filterState.category === 'all'
                ? 'bg-slate-900 text-white'
                : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            All
          </button>
          <button
            onClick={() => handleCategoryChange('menswear')}
            className={`py-2 text-[10px] font-bold uppercase tracking-widest transition-all cursor-pointer ${
              filterState.category === 'menswear'
                ? 'bg-slate-900 text-white'
                : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            Menswear
          </button>
          <button
            onClick={() => handleCategoryChange('kidswear')}
            className={`py-2 text-[10px] font-bold uppercase tracking-widest transition-all cursor-pointer ${
              filterState.category === 'kidswear'
                ? 'bg-slate-900 text-white'
                : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            Kids
          </button>
        </div>
      </div>

      {/* Subcategory Checkboxes */}
      <div className="space-y-2">
        <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block">
          {language === 'hi' ? 'उप-श्रेणी (STYLES):' : 'STYLES & TYPES:'}
        </label>
        <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
          {visibleSubcategories.map((sub) => {
            const isChecked = filterState.subcategories.includes(sub.id);
            return (
              <label
                key={sub.id}
                className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-800 hover:text-slate-900 cursor-pointer select-none"
              >
                <input
                  type="checkbox"
                  checked={isChecked}
                  onChange={() => handleSubcategoryToggle(sub.id)}
                  className="rounded-none border-slate-900 text-slate-900 focus:ring-slate-900 w-4 h-4"
                />
                <span className={isChecked ? 'line-through text-slate-900' : ''}>{sub.label}</span>
              </label>
            );
          })}
        </div>
      </div>

      {/* Price Filter Slider */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-slate-900">
          <span>{language === 'hi' ? 'मूल्य सीमा:' : 'MAX PRICE:'}</span>
          <span className="font-mono text-xs">₹{filterState.priceRange[1]}</span>
        </div>
        <input
          type="range"
          min={300}
          max={6000}
          step={100}
          value={filterState.priceRange[1]}
          onChange={(e) => setFilterState(prev => ({ ...prev, priceRange: [0, Number(e.target.value)] }))}
          className="w-full accent-slate-900 bg-slate-200 h-1 rounded-none cursor-pointer"
        />
        <div className="flex justify-between text-[9px] text-slate-500 font-bold uppercase tracking-widest">
          <span>₹300</span>
          <span>₹6,000</span>
        </div>
      </div>

      {/* Size Filter Pills */}
      <div className="space-y-2">
        <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 block">
          {language === 'hi' ? 'साइज़:' : 'SIZES:'}
        </label>
        <div className="flex flex-wrap gap-1.5">
          {availableSizes.map((sz) => {
            const isSelected = filterState.sizes.includes(sz);
            return (
              <button
                key={sz}
                onClick={() => handleSizeToggle(sz)}
                className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider border cursor-pointer ${
                  isSelected
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-slate-900 border-slate-900 hover:bg-slate-100'
                }`}
              >
                {sz}
              </button>
            );
          })}
        </div>
      </div>

      {/* Special Toggle Options */}
      <div className="pt-4 border-t border-slate-900">
        <label className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-900 cursor-pointer">
          <input
            type="checkbox"
            checked={filterState.discountOnly}
            onChange={(e) => setFilterState(prev => ({ ...prev, discountOnly: e.target.checked }))}
            className="rounded-none border-slate-900 text-slate-900 focus:ring-slate-900 w-4 h-4"
          />
          <span>50% OFF OFFERS ONLY</span>
        </label>
      </div>

    </div>
  );
};
