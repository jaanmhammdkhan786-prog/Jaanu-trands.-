import React, { useState } from 'react';
import { 
  X, 
  Star, 
  Heart, 
  ShoppingBag, 
  Truck, 
  Ruler, 
  ShieldCheck, 
  RefreshCw, 
  Sparkles,
  MapPin
} from 'lucide-react';
import { Product, Review } from '../types';

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (p: Product) => void;
  onAddToCart: (p: Product, size: string, color: string, qty?: number) => void;
  onBuyNow: (p: Product, size: string, color: string) => void;
  onOpenSizeGuide: () => void;
  language: 'en' | 'hi';
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  isOpen,
  onClose,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
  onBuyNow,
  onOpenSizeGuide,
  language
}) => {
  if (!isOpen || !product) return null;

  const [activeImgIndex, setActiveImgIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'M');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0]?.name || 'Standard');
  const [quantity, setQuantity] = useState(1);
  const [pincode, setPincode] = useState('');
  const [pincodeStatus, setPincodeStatus] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'details' | 'reviews'>('details');

  // Dummy Reviews
  const [reviews] = useState<Review[]>([
    {
      id: 'r1',
      userName: 'Amit Sharma',
      rating: 5,
      comment: 'Fitting is absolutely spot on! Fabric texture feels very high-end and soft.',
      date: '2 days ago',
      verifiedPurchase: true
    },
    {
      id: 'r2',
      userName: 'Priya Verma',
      rating: 5,
      comment: 'Bought this for my 6 year old son. Soft cotton lining and super fast delivery by Janu Trends!',
      date: '1 week ago',
      verifiedPurchase: true
    }
  ]);

  const handlePincodeCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (pincode.length === 6 && /^\d+$/.test(pincode)) {
      setPincodeStatus(`VALID PINCODE ${pincode}: GUARANTEED EXPRESS DELIVERY IN 2-3 DAYS!`);
    } else {
      setPincodeStatus('PLEASE ENTER A VALID 6-DIGIT INDIAN PINCODE.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 flex items-center justify-center p-3 sm:p-6 animate-fadeIn overflow-y-auto">
      <div className="bg-white max-w-4xl w-full my-auto border border-slate-900 overflow-hidden relative flex flex-col max-h-[92vh] shadow-lg">
        
        {/* Close Floating Button */}
        <button
          id="product-modal-close-btn"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2.5 bg-slate-900 text-white hover:bg-slate-800 transition-colors cursor-pointer border border-slate-900"
          aria-label="Close detail modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Main Scrollable Body */}
        <div className="overflow-y-auto p-6 sm:p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
            
            {/* Left: Image Gallery */}
            <div className="space-y-3">
              <div className="aspect-3/4 w-full bg-slate-100 border border-slate-900 relative">
                <img
                  src={product.images[activeImgIndex] || product.images[0]}
                  alt={product.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top"
                />

                <button
                  id="product-modal-wishlist-toggle"
                  onClick={() => onToggleWishlist(product)}
                  className={`absolute top-3 left-3 p-2.5 border border-slate-900 transition-all cursor-pointer ${
                    isWishlisted ? 'bg-slate-900 text-white' : 'bg-white text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Thumbnails */}
              {product.images.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {product.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImgIndex(idx)}
                      className={`w-16 h-20 border transition-all cursor-pointer shrink-0 ${
                        activeImgIndex === idx ? 'border-slate-900 ring-1 ring-slate-900' : 'border-slate-300 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Right: Product Info & Buy Controls */}
            <div className="flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold text-slate-900 uppercase tracking-widest bg-slate-100 px-2.5 py-1 border border-slate-900">
                    JANU TRENDS {product.category === 'menswear' ? 'MENSWEAR' : 'KIDS WEAR'}
                  </span>

                  <div className="flex items-center gap-1 text-xs font-bold text-slate-900 border border-slate-900 px-2 py-0.5">
                    <Star className="w-3.5 h-3.5 fill-slate-900 text-slate-900" />
                    <span>{product.rating}</span>
                    <span className="text-slate-500 font-normal">({product.reviewsCount})</span>
                  </div>
                </div>

                <h2 className="text-xl sm:text-2xl font-serif font-bold text-slate-900 uppercase tracking-wide leading-snug mt-1">
                  {language === 'hi' && product.titleHindi ? product.titleHindi : product.title}
                </h2>

                {/* Price Display */}
                <div className="flex items-baseline gap-3 my-3">
                  <span className="text-2xl sm:text-3xl font-mono font-bold text-slate-900">
                    ₹{product.price.toLocaleString('en-IN')}
                  </span>
                  {product.originalPrice > product.price && (
                    <span className="text-sm font-mono text-slate-400 line-through">
                      ₹{product.originalPrice.toLocaleString('en-IN')}
                    </span>
                  )}
                  {product.discountPercentage > 0 && (
                    <span className="bg-slate-900 text-white text-[10px] font-bold uppercase tracking-widest px-2.5 py-0.5 border border-slate-900">
                      SAVE {product.discountPercentage}%
                    </span>
                  )}
                </div>

                {/* Color Selection */}
                {product.colors && product.colors.length > 0 && (
                  <div className="space-y-2 mb-4">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-slate-900 flex items-center justify-between">
                      <span>SELECT COLOR:</span>
                      <span className="text-slate-600">{selectedColor}</span>
                    </label>
                    <div className="flex items-center gap-2">
                      {product.colors.map((c) => (
                        <button
                          key={c.name}
                          onClick={() => setSelectedColor(c.name)}
                          className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider flex items-center gap-2 border transition-all cursor-pointer ${
                            selectedColor === c.name
                              ? 'border-slate-900 bg-slate-900 text-white'
                              : 'border-slate-300 hover:border-slate-900 text-slate-900 bg-white'
                          }`}
                        >
                          <span
                            className="w-3.5 h-3.5 border border-slate-900"
                            style={{ backgroundColor: c.hex }}
                          />
                          <span>{c.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Size Selection */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-slate-900">
                    <span>SELECT SIZE:</span>
                    <button
                      id="product-modal-size-guide-btn"
                      onClick={onOpenSizeGuide}
                      className="text-slate-900 hover:line-through flex items-center gap-1 font-bold underline cursor-pointer"
                    >
                      <Ruler className="w-3.5 h-3.5" />
                      <span>SIZE CHART</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {product.sizes.map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setSelectedSize(sz)}
                        className={`min-w-11 py-2 px-3 text-xs font-bold border transition-all cursor-pointer uppercase ${
                          selectedSize === sz
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-900 border-slate-300 hover:border-slate-900'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center gap-4 mb-4">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-900">
                    QUANTITY:
                  </span>
                  <div className="flex items-center border border-slate-900 bg-slate-50">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-1 text-slate-900 hover:bg-slate-200 font-bold transition-colors cursor-pointer"
                    >
                      -
                    </button>
                    <span className="px-4 py-1 text-xs font-mono font-bold text-slate-900 bg-white border-x border-slate-900">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-1 text-slate-900 hover:bg-slate-200 font-bold transition-colors cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Delivery Pincode Checker */}
                <div className="bg-slate-50 p-3.5 border border-slate-900 space-y-2 mb-4">
                  <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-900">
                    <MapPin className="w-4 h-4 text-slate-900" />
                    <span>CHECK DELIVERY PINCODE:</span>
                  </div>
                  <form onSubmit={handlePincodeCheck} className="flex gap-2">
                    <input
                      type="text"
                      maxLength={6}
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value)}
                      placeholder="e.g. 110001"
                      className="flex-1 bg-white border border-slate-900 px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="bg-slate-900 text-white text-xs font-bold uppercase tracking-widest px-4 py-1.5 border border-slate-900 hover:bg-slate-800 transition-colors cursor-pointer"
                    >
                      CHECK
                    </button>
                  </form>
                  {pincodeStatus && (
                    <p className={`text-[10px] font-bold uppercase tracking-wider ${pincodeStatus.includes('VALID') ? 'text-emerald-800' : 'text-rose-700'}`}>
                      {pincodeStatus}
                    </p>
                  )}
                </div>
              </div>

              {/* Add to Cart / Buy Now Action CTAs */}
              <div className="space-y-2 pt-2 border-t border-slate-900">
                <div className="grid grid-cols-2 gap-3">
                  <button
                    id="modal-add-to-cart-btn"
                    onClick={() => {
                      onAddToCart(product, selectedSize, selectedColor, quantity);
                    }}
                    className="w-full bg-white hover:bg-slate-100 text-slate-900 font-bold py-3.5 px-4 text-xs uppercase tracking-widest flex items-center justify-center gap-2 border border-slate-900 transition-colors cursor-pointer"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>{language === 'hi' ? 'कार्ट में जोड़ें' : 'ADD TO CART'}</span>
                  </button>

                  <button
                    id="modal-buy-now-btn"
                    onClick={() => {
                      onBuyNow(product, selectedSize, selectedColor);
                    }}
                    className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 px-4 text-xs uppercase tracking-widest flex items-center justify-center gap-2 border border-slate-900 transition-colors cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>{language === 'hi' ? 'अभी खरीदें (Buy Now)' : 'BUY NOW'}</span>
                  </button>
                </div>

                {/* Feature Icons */}
                <div className="grid grid-cols-3 gap-2 text-[10px] font-bold uppercase tracking-wider text-slate-900 text-center pt-2">
                  <div className="flex flex-col items-center gap-1 p-2 bg-slate-50 border border-slate-900">
                    <Truck className="w-4 h-4 text-slate-900" />
                    <span>FREE SHIPPING</span>
                  </div>
                  <div className="flex flex-col items-center gap-1 p-2 bg-slate-50 border border-slate-900">
                    <ShieldCheck className="w-4 h-4 text-slate-900" />
                    <span>QUALITY ASSURED</span>
                  </div>
                  <div className="flex flex-col items-center gap-1 p-2 bg-slate-50 border border-slate-900">
                    <RefreshCw className="w-4 h-4 text-slate-900" />
                    <span>7 DAYS RETURN</span>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Description / Reviews Tabbed Section */}
          <div className="mt-8 border-t border-slate-900 pt-6">
            <div className="flex items-center gap-6 border-b border-slate-900 pb-2 mb-4">
              <button
                onClick={() => setActiveTab('details')}
                className={`text-xs font-bold uppercase tracking-widest pb-2 transition-colors cursor-pointer border-b-2 ${
                  activeTab === 'details'
                    ? 'border-slate-900 text-slate-900'
                    : 'border-transparent text-slate-400 hover:text-slate-800'
                }`}
              >
                PRODUCT DETAILS & FABRIC
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`text-xs font-bold uppercase tracking-widest pb-2 transition-colors cursor-pointer border-b-2 flex items-center gap-2 ${
                  activeTab === 'reviews'
                    ? 'border-slate-900 text-slate-900'
                    : 'border-transparent text-slate-400 hover:text-slate-800'
                }`}
              >
                <span>REVIEWS</span>
                <span className="bg-slate-900 text-white text-[10px] px-2 py-0.5">
                  {reviews.length}
                </span>
              </button>
            </div>

            {activeTab === 'details' ? (
              <div className="space-y-4 text-xs text-slate-800 leading-relaxed uppercase tracking-wider">
                <p>
                  {language === 'hi' && product.descriptionHindi ? product.descriptionHindi : product.description}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 border border-slate-900">
                  <div>
                    <span className="font-bold text-slate-900 block mb-1">FABRIC COMPOSITION:</span>
                    <span className="text-slate-700">{product.fabric}</span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 block mb-1">WASH & CARE:</span>
                    <span className="text-slate-700">{product.care}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-3">
                  {reviews.map((rev) => (
                    <div key={rev.id} className="bg-slate-50 p-4 border border-slate-900 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs uppercase tracking-wider">{rev.userName}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{rev.date}</span>
                      </div>
                      <div className="flex items-center gap-1 text-slate-900">
                        {Array.from({ length: rev.rating }).map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 fill-current" />
                        ))}
                      </div>
                      <p className="text-xs text-slate-800 leading-normal pt-1 uppercase tracking-wider">
                        "{rev.comment}"
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
