import React from 'react';
import { SubCategory, ProductCategory } from '../types';

interface CategoryGridProps {
  onSelectSubcategory: (sub: SubCategory, category: ProductCategory) => void;
  language: 'en' | 'hi';
}

export const CategoryGrid: React.FC<CategoryGridProps> = ({
  onSelectSubcategory,
  language
}) => {
  const categories = [
    {
      id: 'mens_ethnic' as SubCategory,
      parentCategory: 'menswear' as ProductCategory,
      title: language === 'hi' ? 'मेन्स सिल्क कुर्ता सेट' : 'Mens Ethnic Kurtas',
      subtitle: language === 'hi' ? 'शादी व त्योहार के लिए' : 'Festive & Wedding Special',
      image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=600',
      tag: 'HOT'
    },
    {
      id: 'mens_shirts' as SubCategory,
      parentCategory: 'menswear' as ProductCategory,
      title: language === 'hi' ? 'कैजुअल और कॉटन शर्ट्स' : 'Mens Cotton Shirts',
      subtitle: language === 'hi' ? 'स्लिम फिट और डेली स्टाइल' : 'Slim Fit & Office Wear',
      image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&q=80&w=600',
      tag: '50% OFF'
    },
    {
      id: 'mens_jackets' as SubCategory,
      parentCategory: 'menswear' as ProductCategory,
      title: language === 'hi' ? 'पार्टी ब्लेज़र व नेहरू जैकेट' : 'Blazers & Nehru Jackets',
      subtitle: language === 'hi' ? 'रॉयल और क्लासिक लुक' : 'Formal & Royal Tuxedos',
      image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=600',
      tag: 'ROYAL'
    },
    {
      id: 'kids_ethnic' as SubCategory,
      parentCategory: 'kidswear' as ProductCategory,
      title: language === 'hi' ? 'लड़कों के कुर्ते और धोती सेट' : 'Boys Ethnic Sets',
      subtitle: language === 'hi' ? 'मुलायम स्किन-फ्रेंडली फैब्रिक' : 'Super Soft Cotton Silk',
      image: 'https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?auto=format&fit=crop&q=80&w=600',
      tag: 'KIDS BEST'
    },
    {
      id: 'kids_girls' as SubCategory,
      parentCategory: 'kidswear' as ProductCategory,
      title: language === 'hi' ? 'गर्ल्स पार्टी फ्रॉक व लहंगा' : 'Girls Party Dresses',
      subtitle: language === 'hi' ? 'फेयरी टेल गौन और लहंगा' : 'Princess Gowns & Lehengas',
      image: 'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?auto=format&fit=crop&q=80&w=600',
      tag: 'NEW'
    },
    {
      id: 'kids_jackets' as SubCategory,
      parentCategory: 'kidswear' as ProductCategory,
      title: language === 'hi' ? 'बच्चों के हुडी और जैकेट' : 'Kids Winter & Hoodies',
      subtitle: language === 'hi' ? 'गरम और आरामदायक' : 'Warm Brushed Fleece',
      image: 'https://images.unsplash.com/photo-1503944583220-79d8926ad5e2?auto=format&fit=crop&q=80&w=600',
      tag: 'WARM'
    }
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 my-10">
      <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-6 pb-4 border-b border-slate-900 gap-2">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-[0.3em] border border-slate-900 px-2 py-0.5 text-slate-900">
            {language === 'hi' ? 'श्रेणियां (CATEGORIES)' : 'CURATED CATEGORIES'}
          </span>
          <h2 className="text-2xl sm:text-4xl font-serif font-extrabold uppercase text-slate-900 tracking-tight mt-2">
            {language === 'hi' ? 'मेन्स और किड्स ट्रेंडिंग कलेक्शन' : 'Popular Mens & Kids Collections'}
          </h2>
        </div>
        <p className="text-slate-600 text-xs uppercase font-bold tracking-widest">
          {language === 'hi' ? 'हर उम्र के लिए बेहतरीन फैशन' : 'Tailored for Every Age & Celebration'}
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {categories.map((cat) => (
          <div
            key={cat.id}
            onClick={() => onSelectSubcategory(cat.id, cat.parentCategory)}
            className="group bg-white border border-slate-900 cursor-pointer hover:bg-slate-900 transition-all duration-300 flex flex-col shadow-sm"
          >
            <div className="aspect-4/5 w-full overflow-hidden relative border-b border-slate-900">
              <img
                src={cat.image}
                alt={cat.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover filter grayscale-20 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-500"
              />
              <span className="absolute top-2 left-2 bg-slate-900 text-white text-[9px] font-bold px-2 py-0.5 uppercase tracking-widest border border-slate-900">
                {cat.tag}
              </span>
            </div>

            <div className="p-3 flex-1 flex flex-col justify-between group-hover:text-white transition-colors">
              <div>
                <h3 className="font-bold text-slate-900 group-hover:text-white text-xs uppercase tracking-wider line-clamp-1">
                  {cat.title}
                </h3>
                <p className="text-[10px] text-slate-500 group-hover:text-slate-300 uppercase tracking-widest line-clamp-1 mt-1 font-semibold">
                  {cat.subtitle}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
