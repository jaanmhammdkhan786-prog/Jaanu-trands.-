export type ProductCategory = 'menswear' | 'kidswear';

export type SubCategory = 
  | 'mens_shirts'
  | 'mens_tshirts'
  | 'mens_ethnic'
  | 'mens_jackets'
  | 'mens_bottoms'
  | 'kids_boys'
  | 'kids_girls'
  | 'kids_ethnic'
  | 'kids_sets'
  | 'kids_jackets';

export interface Product {
  id: string;
  title: string;
  titleHindi?: string;
  category: ProductCategory;
  subcategory: SubCategory;
  price: number;
  originalPrice: number;
  discountPercentage: number;
  rating: number;
  reviewsCount: number;
  images: string[];
  colors: { name: string; hex: string }[];
  sizes: string[];
  tags: string[];
  description: string;
  descriptionHindi?: string;
  fabric: string;
  care: string;
  isNew?: boolean;
  isBestseller?: boolean;
  inStock: boolean;
}

export interface CartItem {
  id: string; // unique cart item id (product.id + size + color)
  product: Product;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
}

export interface WishlistItem {
  product: Product;
}

export interface FilterState {
  searchQuery: string;
  category: 'all' | ProductCategory;
  subcategories: SubCategory[];
  priceRange: [number, number];
  sizes: string[];
  colors: string[];
  sortOption: 'featured' | 'price-low-high' | 'price-high-low' | 'rating' | 'discount';
  discountOnly: boolean;
  inStockOnly: boolean;
}

export interface Order {
  id: string;
  items: CartItem[];
  totalAmount: number;
  discountAmount: number;
  shippingFee: number;
  finalAmount: number;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  address: string;
  pincode: string;
  city: string;
  state: string;
  paymentMethod: 'upi' | 'cod' | 'card' | 'netbanking';
  paymentDetails?: string;
  status: 'Ordered' | 'Packed' | 'Shipped' | 'Out for Delivery' | 'Delivered';
  createdAt: string;
  estimatedDelivery: string;
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
  verifiedPurchase: boolean;
}
