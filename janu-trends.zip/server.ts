import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { PRODUCTS } from './src/data/products.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI client server-side
  const getAiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('GEMINI_API_KEY is missing from environment');
      return null;
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  };

  // API Health Endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', store: 'Janu Trends' });
  });

  // AI Stylist Endpoint
  app.post('/api/ai-stylist', async (req, res) => {
    try {
      const { userPrompt, language = 'en', targetCategory = 'all' } = req.body;

      if (!userPrompt || typeof userPrompt !== 'string') {
        res.status(400).json({ error: 'Prompt string is required' });
        return;
      }

      const ai = getAiClient();
      if (!ai) {
        // Fallback response if key is missing or not configured yet
        res.json({
          advice: language === 'hi' 
            ? 'नमस्ते! जानू ट्रेंड्स स्टाइल असिस्टेंट में आपका स्वागत है। हमारे पास पुरुषों और बच्चों के लिए नवीनतम कुर्तों, शर्ट्स, जीन्स और फेस्टिव वियर का शानदार संग्रह उपलब्ध है।'
            : 'Welcome to Janu Trends AI Stylist! Explore our top recommendations from Menswear and Kids Wear catalog.',
          recommendedProductIds: ['m1', 'k1', 'm2', 'k3'],
        });
        return;
      }

      const catalogSummary = PRODUCTS.map(p => ({
        id: p.id,
        title: p.title,
        category: p.category,
        subcategory: p.subcategory,
        price: p.price,
        tags: p.tags.join(', '),
        fabric: p.fabric
      }));

      const systemPrompt = `You are "Janu AI Stylist", the friendly expert personal fashion consultant for "Janu Trends" (a premier clothing store specializing in Menswear & Kids Wear).
Catalog inventory available:
${JSON.stringify(catalogSummary, null, 2)}

User request: "${userPrompt}"
Preferred Language mode: ${language === 'hi' ? 'Hindi / Hinglish' : 'English'}
Category preference filter: ${targetCategory}

Instructions:
1. Provide warm, encouraging fashion advice (2-3 short sentences) tailored to the user's occasion, budget, or family needs.
2. Select 1 to 4 matching product IDs from the catalog that best fit the query.
3. Return strict JSON format with fields:
   - "advice": string message
   - "recommendedProductIds": array of strings (must be valid IDs from the catalog provided)

Example output format:
{
  "advice": "For Diwali celebrations, our Royal Silk Kurta Set for men paired with the Boys Dhoti Set makes the perfect matching father-son festive outfit!",
  "recommendedProductIds": ["m1", "k1"]
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: systemPrompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const responseText = response.text || '';
      try {
        const parsed = JSON.parse(responseText);
        res.json({
          advice: parsed.advice || 'Here are our recommended Janu Trends fashion picks for you!',
          recommendedProductIds: Array.isArray(parsed.recommendedProductIds) ? parsed.recommendedProductIds : ['m1', 'k1'],
        });
      } catch {
        res.json({
          advice: responseText || 'Check out these top trending styles from Janu Trends!',
          recommendedProductIds: ['m1', 'k1', 'm2'],
        });
      }
    } catch (err: any) {
      console.error('Error in /api/ai-stylist:', err);
      res.status(500).json({
        error: 'Failed to generate style recommendation',
        advice: 'Discover our bestsellers in Menswear and Kids Wear below!',
        recommendedProductIds: ['m1', 'm2', 'k1', 'k2'],
      });
    }
  });

  // Vite Middleware in Development or Static Server in Production
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Janu Trends Server running on http://localhost:${PORT}`);
  });
}

startServer();
